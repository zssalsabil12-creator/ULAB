#!/usr/bin/env node

/**
 * Secret Scanner for ULAB
 * 
 * This script scans the project for potential secrets:
 * - API keys
 * - Access tokens
 * - Passwords
 * - Private keys
 * - Hardcoded credentials
 * 
 * Usage: node scan-secrets.js
 */

const fs = require('fs');
const path = require('path');

// Patterns to detect secrets
const SECRET_PATTERNS = [
  { name: 'AWS Access Key', pattern: /AKIA[0-9A-Z]{16}/ },
  { name: 'GitHub Token', pattern: /ghp_[a-zA-Z0-9]{36}/ },
  { name: 'OpenAI API Key', pattern: /sk-[a-zA-Z0-9]{32,}/ },
  { name: 'Private Key', pattern: /-----BEGIN (RSA |EC |DSA )?PRIVATE KEY-----/ },
  { name: 'Password Assignment', pattern: /password\s*[:=]\s*['"][^'"]+['"]/i },
  { name: 'API Key Assignment', pattern: /api[_-]?key\s*[:=]\s*['"][^'"]+['"]/i },
  { name: 'Secret Assignment', pattern: /secret\s*[:=]\s*['"][^'"]+['"]/i },
  { name: 'Token Assignment', pattern: /token\s*[:=]\s*['"][^'"]+['"]/i },
];

// Directories to skip
const SKIP_DIRS = [
  'node_modules',
  '.git',
  'dist',
  'build',
  'coverage',
  '.cache',
];

// File extensions to scan
const SCAN_EXTENSIONS = [
  '.ts', '.tsx', '.js', '.jsx',
  '.json', '.yaml', '.yml',
  '.env', '.env.local', '.env.*',
  '.md', '.txt',
];

interface SecretFinding {
  file: string;
  line: number;
  pattern: string;
  content: string;
}

const findings: SecretFinding[] = [];

function shouldSkipDir(dirName: string): boolean {
  return SKIP_DIRS.includes(dirName);
}

function shouldScanFile(fileName: string): boolean {
  return SCAN_EXTENSIONS.some(ext => fileName.endsWith(ext));
}

function scanFile(filePath: string): void {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const lines = content.split('\n');
    
    lines.forEach((line, index) => {
      SECRET_PATTERNS.forEach(({ name, pattern }) => {
        if (pattern.test(line)) {
          findings.push({
            file: filePath,
            line: index + 1,
            pattern: name,
            content: line.trim().substring(0, 100),
          });
        }
      });
    });
  } catch (error) {
    // Skip files that can't be read
  }
}

function scanDirectory(dirPath: string): void {
  try {
    const entries = fs.readdirSync(dirPath, { withFileTypes: true });
    
    entries.forEach(entry => {
      const fullPath = path.join(dirPath, entry.name);
      
      if (entry.isDirectory()) {
        if (!shouldSkipDir(entry.name)) {
          scanDirectory(fullPath);
        }
      } else if (entry.isFile()) {
        if (shouldScanFile(entry.name)) {
          scanFile(fullPath);
        }
      }
    });
  } catch (error) {
    // Skip directories that can't be read
  }
}

console.log('🔍 Scanning for secrets...\n');

// Scan the project
const projectRoot = __dirname;
scanDirectory(projectRoot);

// Report findings
if (findings.length === 0) {
  console.log('✅ No secrets found!');
  console.log('\nThe project is clean.');
  process.exit(0);
} else {
  console.log(`❌ Found ${findings.length} potential secret(s):\n`);
  
  findings.forEach((finding, index) => {
    console.log(`${index + 1}. ${finding.pattern}`);
    console.log(`   File: ${finding.file}`);
    console.log(`   Line: ${finding.line}`);
    console.log(`   Content: ${finding.content}`);
    console.log('');
  });
  
  console.log('\n⚠️  ACTION REQUIRED:');
  console.log('1. Review each finding');
  console.log('2. Remove or replace real secrets');
  console.log('3. Use environment variables for sensitive data');
  console.log('4. Add sensitive files to .gitignore');
  console.log('5. Rebuild the project');
  
  process.exit(1);
}
