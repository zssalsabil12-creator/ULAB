#!/usr/bin/env node

/**
 * Build Package Script for ULAB
 * Creates a downloadable ZIP package with all necessary files
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const PACKAGE_NAME = 'ulab-v1.0.0';
const OUTPUT_DIR = path.join(__dirname, 'dist-package');
const ZIP_FILE = path.join(__dirname, `${PACKAGE_NAME}.zip`);

// Files and directories to include in the package
const INCLUDE = [
  'dist',
  'extension',
  'agent',
  'test-project',
  'windows-runtime-test',
  'README.md',
  'INSTALL.md',
  'USER_GUIDE.md',
  'SECURITY.md',
  'PRIVACY.md',
  'TROUBLESHOOTING.md',
  'RELEASE_NOTES.md',
  'ARCHITECTURE.md',
  'TERMS.md',
  'PRIVACY_POLICY.md',
  'WINDOWS_RUNTIME_CHECKLIST.md',
  'FINAL_PRE_RUNTIME_AUDIT.md',
  'package.json',
  'package-lock.json',
  'tsconfig.json',
  'vite.config.js',
  'download.html',
];

// Files to exclude
const EXCLUDE = [
  'node_modules',
  '.git',
  '.env',
  '*.log',
  '.DS_Store',
  'Thumbs.db',
];

console.log('🔨 Building ULAB Package...\n');

// Step 1: Clean output directory
console.log('📦 Step 1: Cleaning output directory...');
if (fs.existsSync(OUTPUT_DIR)) {
  fs.rmSync(OUTPUT_DIR, { recursive: true, force: true });
}
fs.mkdirSync(OUTPUT_DIR, { recursive: true });
console.log('✅ Output directory cleaned\n');

// Step 2: Build the project
console.log('🏗️  Step 2: Building project...');
try {
  execSync('npm run build', { stdio: 'inherit' });
  console.log('✅ Project built successfully\n');
} catch (error) {
  console.error('❌ Build failed:', error.message);
  process.exit(1);
}

// Step 3: Copy files to package directory
console.log('📋 Step 3: Copying files to package...');
let copiedCount = 0;

function shouldExclude(filePath) {
  return EXCLUDE.some(pattern => {
    if (pattern.startsWith('*')) {
      return filePath.endsWith(pattern.slice(1));
    }
    return filePath.includes(pattern);
  });
}

function copyRecursive(src, dest) {
  const stats = fs.statSync(src);
  
  if (stats.isDirectory()) {
    if (!fs.existsSync(dest)) {
      fs.mkdirSync(dest, { recursive: true });
    }
    
    const files = fs.readdirSync(src);
    for (const file of files) {
      const srcPath = path.join(src, file);
      const destPath = path.join(dest, file);
      
      if (!shouldExclude(srcPath)) {
        copyRecursive(srcPath, destPath);
      }
    }
  } else {
    fs.copyFileSync(src, dest);
    copiedCount++;
  }
}

for (const item of INCLUDE) {
  const srcPath = path.join(__dirname, item);
  const destPath = path.join(OUTPUT_DIR, item);
  
  if (fs.existsSync(srcPath)) {
    copyRecursive(srcPath, destPath);
    console.log(`  ✓ Copied: ${item}`);
  } else {
    console.log(`  ⚠ Not found: ${item}`);
  }
}

console.log(`\n✅ Copied ${copiedCount} files\n`);

// Step 4: Create README.txt for the package
console.log('📝 Step 4: Creating package README...');
const readmeContent = `# Universal Local AI Bridge (ULAB) v1.0.0

## مرحباً بك في ULAB!

شكراً لتحميل Universal Local AI Bridge. هذا الملف سيشرح لك كيفية البدء.

## البدء السريع

### 1. تثبيت المكتبات
افتح Terminal في هذا المجلد وشغل:
\`\`\`bash
npm install
\`\`\`

### 2. تشغيل التطبيق
\`\`\`bash
npm run dev
\`\`\`

### 3. فتح المتصفح
افتح المتصفح على: http://localhost:5173

## الاستخدام

1. **اختر مجلد المشروع**: اضغط على "اختيار مشروع" واختر مجلد المشروع
2. **انتظر الفهرسة**: سيقوم ULAB بفهرسة الملفات تلقائياً
3. **اطرح سؤالك**: اكتب سؤالك في مربع البحث
4. **راجع النتائج**: سيعرض ULAB الملفات ذات الصلة
5. **استخدم السياق**: انسخ السياق والصقه في ChatGPT أو Gemini

## المتطلبات

- Node.js 18 أو أحدث
- متصفح حديث (Chrome, Edge, Firefox)
- 100 MB مساحة فارغة

## الملفات المهمة

- \`README.md\` - التوثيق الرئيسي
- \`INSTALL.md\` - دليل التثبيت المفصل
- \`USER_GUIDE.md\` - دليل المستخدم
- \`SECURITY.md\` - معلومات الأمان
- \`PRIVACY.md\` - سياسة الخصوصية
- \`WINDOWS_RUNTIME_CHECKLIST.md\` - قائمة اختبار Windows

## الدعم

- التوثيق: https://github.com/yourusername/ulab
- المشاكل: https://github.com/yourusername/ulab/issues
- المناقشات: https://github.com/yourusername/ulab/discussions

## الترخيص

مفتوح المصدر تحت رخصة MIT

---

استمتع باستخدام ULAB! 🚀
`;

fs.writeFileSync(path.join(OUTPUT_DIR, 'README.txt'), readmeContent);
console.log('✅ README.txt created\n');

// Step 5: Create ZIP file
console.log('🗜️  Step 5: Creating ZIP file...');
try {
  // Use PowerShell on Windows, zip on Unix
  if (process.platform === 'win32') {
    execSync(`powershell -Command "Compress-Archive -Path '${OUTPUT_DIR}' -DestinationPath '${ZIP_FILE}' -Force"`, { stdio: 'inherit' });
  } else {
    execSync(`cd "${OUTPUT_DIR}" && zip -r "../${PACKAGE_NAME}.zip" .`, { stdio: 'inherit' });
  }
  console.log(`✅ ZIP file created: ${ZIP_FILE}\n`);
} catch (error) {
  console.error('⚠️  Could not create ZIP file automatically');
  console.log('   You can manually zip the dist-package folder');
}

// Step 6: Summary
console.log('📊 Package Summary:');
console.log(`   📦 Package directory: ${OUTPUT_DIR}`);
console.log(`   🗜️  ZIP file: ${ZIP_FILE}`);
console.log(`   📄 Files copied: ${copiedCount}`);

// Get package size
if (fs.existsSync(ZIP_FILE)) {
  const stats = fs.statSync(ZIP_FILE);
  const sizeMB = (stats.size / (1024 * 1024)).toFixed(2);
  console.log(`   💾 ZIP size: ${sizeMB} MB`);
}

console.log('\n✅ Package build complete!');
console.log('\n📖 Next steps:');
console.log('   1. Extract the ZIP file');
console.log('   2. Run: npm install');
console.log('   3. Run: npm run dev');
console.log('   4. Open: http://localhost:5173');
console.log('\n🚀 Happy coding with ULAB!\n');
