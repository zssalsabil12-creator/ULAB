#!/usr/bin/env node

/**
 * Build Chrome Extension
 * 
 * This script builds the Chrome extension by:
 * 1. Creating dist/extension directory
 * 2. Copying all extension files
 * 3. Creating ZIP package
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const EXTENSION_DIR = path.join(__dirname, 'extension');
const DIST_DIR = path.join(__dirname, 'dist', 'extension');
const ZIP_PATH = path.join(__dirname, 'dist', 'UniversalLocalAIBridge-extension.zip');

console.log('🔨 Building Chrome Extension...\n');

// Clean dist directory
if (fs.existsSync(DIST_DIR)) {
  console.log('🧹 Cleaning dist/extension...');
  fs.rmSync(DIST_DIR, { recursive: true, force: true });
}

// Create dist directory
console.log('📁 Creating dist/extension...');
fs.mkdirSync(DIST_DIR, { recursive: true });

// Copy extension files
console.log('📋 Copying extension files...');

function copyDir(src, dest) {
  fs.mkdirSync(dest, { recursive: true });
  const entries = fs.readdirSync(src, { withFileTypes: true });
  
  for (const entry of entries) {
    const srcPath = path.join(src, entry.name);
    const destPath = path.join(dest, entry.name);
    
    if (entry.isDirectory()) {
      copyDir(srcPath, destPath);
    } else {
      fs.copyFileSync(srcPath, destPath);
      console.log(`  ✅ ${entry.name}`);
    }
  }
}

copyDir(EXTENSION_DIR, DIST_DIR);

// Verify all required files exist
console.log('\n🔍 Verifying required files...');
const requiredFiles = [
  'manifest.json',
  'background/service-worker.js',
  'sidepanel/index.html',
  'sidepanel/styles.css',
  'sidepanel/panel.js',
  'content/content.js',
  'icons/icon16.png',
  'icons/icon48.png',
  'icons/icon128.png',
];

let allFilesExist = true;
for (const file of requiredFiles) {
  const filePath = path.join(DIST_DIR, file);
  if (fs.existsSync(filePath)) {
    console.log(`  ✅ ${file}`);
  } else {
    console.log(`  ❌ ${file} - MISSING!`);
    allFilesExist = false;
  }
}

if (!allFilesExist) {
  console.error('\n❌ Build failed: Missing required files!');
  process.exit(1);
}

// Create ZIP package
console.log('\n📦 Creating ZIP package...');
try {
  // Use PowerShell on Windows or zip on Unix
  if (process.platform === 'win32') {
    execSync(`powershell -command "Compress-Archive -Path '${DIST_DIR}' -DestinationPath '${ZIP_PATH}' -Force"`, { stdio: 'inherit' });
  } else {
    execSync(`cd dist && zip -r UniversalLocalAIBridge-extension.zip extension`, { stdio: 'inherit' });
  }
  console.log(`\n✅ ZIP created: ${ZIP_PATH}`);
} catch (error) {
  console.warn('\n⚠️  Could not create ZIP automatically.');
  console.warn('You can create it manually:');
  console.warn(`  cd dist && zip -r UniversalLocalAIBridge-extension.zip extension`);
}

// Verify manifest.json
console.log('\n🔍 Verifying manifest.json...');
const manifestPath = path.join(DIST_DIR, 'manifest.json');
try {
  const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf-8'));
  
  console.log(`  ✅ Manifest version: ${manifest.manifest_version}`);
  console.log(`  ✅ Name: ${manifest.name}`);
  console.log(`  ✅ Version: ${manifest.version}`);
  console.log(`  ✅ Side panel: ${manifest.side_panel?.default_path || 'Not configured'}`);
  console.log(`  ✅ Background: ${manifest.background?.service_worker || 'Not configured'}`);
  console.log(`  ✅ Permissions: ${manifest.permissions?.join(', ') || 'None'}`);
  
  // Check for common issues
  if (manifest.manifest_version !== 3) {
    console.warn('  ⚠️  Warning: Manifest version should be 3');
  }
  
  if (!manifest.permissions?.includes('nativeMessaging')) {
    console.warn('  ⚠️  Warning: nativeMessaging permission not found');
  }
  
} catch (error) {
  console.error('  ❌ Error reading manifest.json:', error.message);
  process.exit(1);
}

console.log('\n✅ Build complete!');
console.log('\n📦 Output:');
console.log(`  Extension: ${DIST_DIR}`);
console.log(`  ZIP: ${ZIP_PATH}`);
console.log('\n🚀 Next steps:');
console.log('  1. Open Chrome and go to chrome://extensions/');
console.log('  2. Enable "Developer mode"');
console.log('  3. Click "Load unpacked"');
console.log(`  4. Select: ${DIST_DIR}`);
console.log('  5. Test the extension!');
