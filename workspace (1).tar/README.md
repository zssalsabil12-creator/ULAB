# Universal Local AI Bridge (ULAB)

<div align="center">

![ULAB](https://img.shields.io/badge/ULAB-Universal%20Local%20AI%20Bridge-purple?style=for-the-badge)
![Version](https://img.shields.io/badge/version-1.0.0-blue?style=for-the-badge)
![License](https://img.shields.io/badge/license-MIT-green?style=for-the-badge)
![Platform](https://img.shields.io/badge/platform-Windows%20%7C%20Chrome-blue?style=for-the-badge)

**Connect your web AI to your local projects — privately.**

[Download](#installation) • [Documentation](#documentation) • [Security](#security) • [Privacy](#privacy)

</div>

---

## 🎯 What is ULAB?

Universal Local AI Bridge (ULAB) is a privacy-first tool that connects web-based AI chatbots (ChatGPT, Gemini, DeepSeek, etc.) to your local computer and projects.

### Key Features

✅ **Privacy-First** - All processing happens on your device  
✅ **Local-First** - No cloud backend, no project upload  
✅ **Provider-Independent** - Works with any web AI chatbot  
✅ **Large Project Support** - Index and search projects with thousands of files  
✅ **Secure Execution** - Controlled command execution with approval workflow  
✅ **Free Forever** - No API keys, no paid infrastructure  

### How It Works

```
Your Web AI (ChatGPT/Gemini/etc.)
         ↓
ULAB Extension (Chrome Side Panel)
         ↓
ULAB Local Agent (Windows)
         ↓
Your Local Projects
```

1. **Select Project** - Choose your local project folder
2. **Build Context** - ULAB intelligently selects relevant files
3. **Send to AI** - Copy context to your favorite AI chatbot
4. **Review Changes** - See AI-proposed changes as diffs
5. **Apply Safely** - Approve and apply changes with rollback support

---

## 📦 Installation

### Windows Installation

1. **Download** the latest release from the [Releases page](https://github.com/yourusername/ulab/releases)

2. **Run the installer**:
   ```cmd
   ULAB-Setup.exe
   ```
   Or run `windows-installer.bat` as Administrator

3. **Follow the installation wizard**:
   - Accept the license agreement
   - Choose installation directory (default: `C:\Program Files\ULAB`)
   - Enter your Chrome Extension ID (see below)
   - Complete installation

4. **Load the Chrome Extension**:
   - Open Chrome
   - Go to `chrome://extensions/`
   - Enable "Developer mode" (toggle in top-right)
   - Click "Load unpacked"
   - Select: `C:\Program Files\ULAB\extension`
   - Copy the Extension ID

5. **Update Native Messaging** (if needed):
   - The installer will prompt you for the Extension ID
   - Enter the ID you copied in step 4

6. **Start using ULAB**:
   - Click the ULAB icon in Chrome toolbar
   - Click "Connect Agent"
   - Select a project
   - Start building context!

### Manual Installation

If you prefer manual installation:

```cmd
# 1. Install Local Agent
cd agent
npm install
npm run build
npm run package

# 2. Register Native Messaging Host
# Edit agent\native-messaging\com.ulab.agent.json with your Extension ID
# Copy to %APPDATA%\Google\Chrome\NativeMessagingHosts\

# 3. Load Extension in Chrome
# chrome://extensions/ → Developer mode → Load unpacked → Select extension/
```

---

## 📖 Documentation

### Getting Started

1. **[User Guide](docs/USER_GUIDE.md)** - Complete user documentation
2. **[Installation Guide](docs/INSTALL.md)** - Detailed installation instructions
3. **[Architecture](docs/ARCHITECTURE.md)** - Technical architecture overview

### Advanced Topics

4. **[Security](docs/SECURITY.md)** - Security model and controls
5. **[Privacy](docs/PRIVACY.md)** - Privacy policy and data handling
6. **[Troubleshooting](docs/TROUBLESHOOTING.md)** - Common issues and solutions

### Development

7. **[Development Guide](docs/DEVELOPMENT.md)** - Contributing to ULAB
8. **[Release Notes](docs/RELEASE_NOTES.md)** - Version history

---

## 🔒 Security

ULAB implements comprehensive security controls:

### Command Execution Security
- ✅ Allowlist-based command approval
- ✅ Blocked pattern detection (command chaining, shell injection)
- ✅ Risk level classification (low/medium/high/critical)
- ✅ User approval for high-risk operations
- ✅ Project root enforcement

### Sensitive File Protection
- ✅ Blocks access to `.env`, `.key`, `credentials.json`
- ✅ Prevents committing sensitive files to Git
- ✅ Protects private keys and authentication configs

### AI Safety
- ✅ AI output never bypasses validation
- ✅ Stale patch detection prevents overwriting user changes
- ✅ Rollback support for safe recovery

**Learn more**: [Security Documentation](docs/SECURITY.md)

---

## 🛡️ Privacy

ULAB is designed with privacy as a core principle:

### What Stays Local
- ✅ Project indexing and search
- ✅ Context generation
- ✅ Command execution
- ✅ Git operations
- ✅ File modifications

### What You Control
- ✅ What context to send to AI
- ✅ Which files to include
- ✅ Which changes to apply

### Important Note
When you intentionally send generated context to a third-party AI chatbot (ChatGPT, Gemini, etc.), that information is processed by that provider according to its own policies.

**Learn more**: [Privacy Documentation](docs/PRIVACY.md)

---

## 🚀 Quick Start

### First Project

1. **Open ULAB** in Chrome
2. **Connect Agent** - Click "Connect Agent" button
3. **Select Project** - Choose your project folder
4. **Wait for Indexing** - ULAB indexes your project
5. **Build Context** - Ask a question or select files
6. **Send to AI** - Copy context to your AI chatbot
7. **Review & Apply** - Review AI suggestions and apply changes

### Example Workflow

```
User: "Why is authentication failing?"

ULAB:
1. Analyzes question
2. Finds relevant files:
   - src/auth/login.ts
   - src/auth/session.ts
   - src/middleware/auth.ts
3. Builds context package
4. User copies to ChatGPT
5. AI analyzes and suggests fix
6. User reviews diff
7. User approves and applies
8. ULAB runs tests
9. All tests pass ✓
```

---

## 📊 Features

### Project Intelligence
- ✅ Large project indexing (10,000+ files)
- ✅ Smart search with relevance scoring
- ✅ Import/dependency graph
- ✅ Language detection
- ✅ Project structure analysis

### AI Integration
- ✅ Generic Mode (works with any AI)
- ✅ Provider adapters (ChatGPT, Gemini, DeepSeek)
- ✅ Context package management
- ✅ Reusable context templates

### Execution & Verification
- ✅ Test runner (npm test, yarn test)
- ✅ Build runner (npm run build)
- ✅ Typecheck runner (tsc)
- ✅ Lint runner (eslint)
- ✅ Git integration (status, diff, commit)

### Safety Features
- ✅ Change review with diff view
- ✅ Stale patch detection
- ✅ Rollback support
- ✅ Operation audit log
- ✅ Process cancellation

---

## 🤝 Contributing

We welcome contributions! See [Development Guide](docs/DEVELOPMENT.md) for details.

### Quick Start for Developers

```bash
# Clone repository
git clone https://github.com/yourusername/ulab.git
cd ulab

# Install dependencies
npm install

# Run development server
npm run dev

# Build for production
npm run build

# Run tests
npm test
```

---

## 📄 License

ULAB is open-source software licensed under the [MIT License](LICENSE).

---

## 🙏 Acknowledgments

- Built with React, TypeScript, and Tailwind CSS
- Icons by Lucide
- Inspired by the need for privacy-first AI tools

---

## 📞 Support

- **Documentation**: [docs/](docs/)
- **Issues**: [GitHub Issues](https://github.com/yourusername/ulab/issues)
- **Discussions**: [GitHub Discussions](https://github.com/yourusername/ulab/discussions)

---

<div align="center">

**Made with ❤️ for developers who value privacy**

**Local by Default • Privacy by Design • Free Forever**

</div>
