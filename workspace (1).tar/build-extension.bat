@echo off
REM Universal Local AI Bridge - Extension Builder

echo ========================================
echo Building ULAB Chrome Extension
echo ========================================
echo.

REM Create output directory
if not exist "dist\extension" mkdir "dist\extension"

REM Copy extension files
echo Copying extension files...
xcopy /E /Y /Q extension\* dist\extension\ >nul

echo.
echo Extension built successfully!
echo.
echo Output: dist\extension\
echo.
echo To load the extension:
echo 1. Open Chrome and go to chrome://extensions/
echo 2. Enable "Developer mode"
echo 3. Click "Load unpacked"
echo 4. Select the dist\extension folder
echo.

REM Create ZIP package
echo Creating ZIP package...
cd dist
powershell -command "Compress-Archive -Path extension -DestinationPath UniversalLocalAIBridge-extension.zip -Force"
cd ..

echo ZIP package created: dist\UniversalLocalAIBridge-extension.zip
echo.
pause
