@echo off
REM ============================================================================
REM ULAB Windows Runtime Test Package Builder
REM ============================================================================
REM This script creates the final Windows test package
REM ============================================================================

setlocal enabledelayedexpansion

echo.
echo ============================================================================
echo   Universal Local AI Bridge - Windows Test Package Builder
echo ============================================================================
echo.

set PACKAGE_DIR=UniversalLocalAIBridge-Windows-Test

REM Create package directory
echo [1/10] Creating package directory...
if exist "%PACKAGE_DIR%" (
    rmdir /s /q "%PACKAGE_DIR%"
)
mkdir "%PACKAGE_DIR%"
echo [PASS] Package directory created
echo.

REM Copy extension
echo [2/10] Copying extension...
xcopy /E /I /Y "extension" "%PACKAGE_DIR%\extension" >nul
echo [PASS] Extension copied
echo.

REM Copy windows-runtime-test scripts
echo [3/10] Copying test scripts...
xcopy /Y "windows-runtime-test\diagnose.bat" "%PACKAGE_DIR%\" >nul
xcopy /Y "windows-runtime-test\run-tests.bat" "%PACKAGE_DIR%\" >nul
xcopy /Y "windows-runtime-test\install-agent.bat" "%PACKAGE_DIR%\" >nul
xcopy /Y "windows-runtime-test\uninstall-agent.bat" "%PACKAGE_DIR%\" >nul
xcopy /Y "windows-runtime-test\generate-test-report.bat" "%PACKAGE_DIR%\" >nul
echo [PASS] Test scripts copied
echo.

REM Copy documentation
echo [4/10] Copying documentation...
xcopy /Y "windows-runtime-test\WINDOWS_RUNTIME_GUIDE.md" "%PACKAGE_DIR%\" >nul
xcopy /Y "windows-runtime-test\TEST_REPORT.md" "%PACKAGE_DIR%\" >nul
xcopy /Y "windows-runtime-test\CHROME_TEST_ASSISTANT.html" "%PACKAGE_DIR%\" >nul
xcopy /Y "windows-runtime-test\README.md" "%PACKAGE_DIR%\" >nul
echo [PASS] Documentation copied
echo.

REM Copy agent source
echo [5/10] Copying agent source...
xcopy /E /I /Y "agent" "%PACKAGE_DIR%\agent" >nul
echo [PASS] Agent source copied
echo.

REM Copy test project
echo [6/10] Copying test project...
xcopy /E /I /Y "test-project" "%PACKAGE_DIR%\test-project" >nul
echo [PASS] Test project copied
echo.

REM Copy main documentation
echo [7/10] Copying main documentation...
xcopy /Y "README.md" "%PACKAGE_DIR%\" >nul
xcopy /Y "INSTALL.md" "%PACKAGE_DIR%\" >nul
xcopy /Y "USER_GUIDE.md" "%PACKAGE_DIR%\" >nul
xcopy /Y "ARCHITECTURE.md" "%PACKAGE_DIR%\" >nul
xcopy /Y "SECURITY.md" "%PACKAGE_DIR%\" >nul
xcopy /Y "PRIVACY.md" "%PACKAGE_DIR%\" >nul
echo [PASS] Main documentation copied
echo.

REM Copy build scripts
echo [8/10] Copying build scripts...
xcopy /Y "build-extension.bat" "%PACKAGE_DIR%\" >nul
xcopy /Y "build-extension.js" "%PACKAGE_DIR%\" >nul
xcopy /Y "create-png-placeholders.js" "%PACKAGE_DIR%\" >nul
echo [PASS] Build scripts copied
echo.

REM Copy package files
echo [9/10] Copying package files...
xcopy /Y "package.json" "%PACKAGE_DIR%\" >nul
xcopy /Y "package-lock.json" "%PACKAGE_DIR%\" >nul
xcopy /Y "tsconfig.json" "%PACKAGE_DIR%\" >nul
echo [PASS] Package files copied
echo.

REM Create quick start guide
echo [10/10] Creating quick start guide...
(
echo # ULAB Windows Test Package - Quick Start
echo.
echo ## Step 1: Run Diagnostics
echo Double-click: diagnose.bat
echo.
echo ## Step 2: Run Automated Tests
echo Double-click: run-tests.bat
echo.
echo ## Step 3: Install Agent
echo Right-click install-agent.bat → Run as administrator
echo.
echo ## Step 4: Load Extension
echo 1. Open Chrome
echo 2. Go to chrome://extensions/
echo 3. Enable "Developer mode"
echo 4. Click "Load unpacked"
echo 5. Select the "extension" folder
echo 6. Copy the Extension ID
echo.
echo ## Step 5: Complete Manual Tests
echo Open CHROME_TEST_ASSISTANT.html in Chrome
echo.
echo ## Need Help?
echo Read WINDOWS_RUNTIME_GUIDE.md
) > "%PACKAGE_DIR%\QUICK_START.md"
echo [PASS] Quick start guide created
echo.

REM Create package summary
echo.
echo ============================================================================
echo   PACKAGE SUMMARY
echo ============================================================================
echo.
echo Package created: %PACKAGE_DIR%
echo.
echo Contents:
echo   - extension/              Chrome extension
echo   - agent/                  Local Agent source
echo   - test-project/           Test project
echo   - diagnose.bat            System diagnostic
echo   - run-tests.bat           Automated tests
echo   - install-agent.bat       Agent installer
echo   - uninstall-agent.bat     Agent uninstaller
echo   - generate-test-report.bat Test report generator
echo   - WINDOWS_RUNTIME_GUIDE.md Testing guide
echo   - TEST_REPORT.md          Test report template
echo   - CHROME_TEST_ASSISTANT.html Interactive checklist
echo   - README.md               Package documentation
echo   - QUICK_START.md          Quick start guide
echo.
echo Next steps:
echo 1. Copy the "%PACKAGE_DIR%" folder to a Windows machine
echo 2. Follow QUICK_START.md
echo 3. Complete all tests
echo 4. Generate test report
echo.
echo ============================================================================
echo.

pause
