// Universal Local AI Bridge - Side Panel Script

let backgroundPort = null;
let isConnected = false;
let currentProject = null;
let fileTree = [];
let selectedFiles = new Set();

// Connect to background script
function connectToBackground() {
  backgroundPort = chrome.runtime.connect({ name: 'sidepanel' });
  
  backgroundPort.onMessage.addListener((message) => {
    console.log('[ULAB Panel] Message from background:', message);
    
    if (message.type === 'status') {
      updateConnectionStatus(message.isConnected);
    } else if (message.type === 'agent_message') {
      handleAgentMessage(message.data);
    } else if (message.type === 'agent_disconnected') {
      updateConnectionStatus(false);
    }
  });
  
  // Request initial status
  backgroundPort.postMessage({ type: 'get_status' });
}

// Update connection status UI
function updateConnectionStatus(connected) {
  isConnected = connected;
  const statusEl = document.getElementById('status');
  const statusText = document.getElementById('connection-status');
  const connectBtn = document.getElementById('connect-btn');
  
  if (connected) {
    statusEl.classList.add('connected');
    statusEl.querySelector('.status-text').textContent = 'Connected';
    statusText.textContent = 'Connected to local agent';
    connectBtn.textContent = 'Disconnect';
    connectBtn.classList.remove('btn-primary');
    connectBtn.classList.add('btn-secondary');
    
    // Show project section
    document.getElementById('project-section').style.display = 'block';
  } else {
    statusEl.classList.remove('connected');
    statusEl.querySelector('.status-text').textContent = 'Disconnected';
    statusText.textContent = 'Not connected to local agent';
    connectBtn.textContent = 'Connect Agent';
    connectBtn.classList.add('btn-primary');
    connectBtn.classList.remove('btn-secondary');
    
    // Hide sections
    document.getElementById('project-section').style.display = 'none';
    document.getElementById('explorer-section').style.display = 'none';
    document.getElementById('context-section').style.display = 'none';
    document.getElementById('permissions-section').style.display = 'none';
  }
}

// Handle messages from agent
function handleAgentMessage(message) {
  console.log('[ULAB Panel] Agent message:', message);
  
  if (message.action === 'project.selected') {
    currentProject = message.data;
    document.getElementById('project-name').textContent = currentProject.name;
    document.getElementById('explorer-section').style.display = 'block';
    document.getElementById('context-section').style.display = 'block';
    document.getElementById('permissions-section').style.display = 'block';
  } else if (message.action === 'files.list') {
    fileTree = message.data;
    renderFileTree(fileTree);
  } else if (message.action === 'search.results') {
    renderSearchResults(message.data);
  }
}

// Render file tree
function renderFileTree(files, container = null) {
  const treeEl = container || document.getElementById('file-tree');
  if (!container) treeEl.innerHTML = '';
  
  files.forEach(file => {
    const item = document.createElement('div');
    item.className = 'file-item';
    
    if (file.type === 'directory') {
      item.innerHTML = `
        <span class="folder-toggle">▶</span>
        <svg class="file-icon" viewBox="0 0 24 24" fill="currentColor">
          <path d="M10 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z"/>
        </svg>
        <span class="file-name">${file.name}</span>
      `;
      
      item.addEventListener('click', () => {
        const children = item.nextElementSibling;
        if (children && children.classList.contains('folder-children')) {
          children.style.display = children.style.display === 'none' ? 'block' : 'none';
          item.querySelector('.folder-toggle').textContent = 
            children.style.display === 'none' ? '▶' : '▼';
        }
      });
      
      treeEl.appendChild(item);
      
      if (file.children && file.children.length > 0) {
        const childrenContainer = document.createElement('div');
        childrenContainer.className = 'folder-children';
        childrenContainer.style.display = 'none';
        renderFileTree(file.children, childrenContainer);
        treeEl.appendChild(childrenContainer);
      }
    } else {
      item.innerHTML = `
        <span style="width: 16px;"></span>
        <svg class="file-icon" viewBox="0 0 24 24" fill="currentColor">
          <path d="M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z"/>
        </svg>
        <span class="file-name">${file.name}</span>
      `;
      
      item.addEventListener('click', () => {
        if (selectedFiles.has(file.path)) {
          selectedFiles.delete(file.path);
          item.classList.remove('selected');
        } else {
          selectedFiles.add(file.path);
          item.classList.add('selected');
        }
        updateContextCount();
      });
      
      treeEl.appendChild(item);
    }
  });
}

// Update context count
function updateContextCount() {
  document.getElementById('context-count').textContent = `${selectedFiles.size} files selected`;
  
  const selectedFilesEl = document.getElementById('selected-files');
  selectedFilesEl.innerHTML = '';
  
  selectedFiles.forEach(path => {
    const fileEl = document.createElement('div');
    fileEl.className = 'selected-file';
    fileEl.innerHTML = `
      <span>${path}</span>
      <button class="remove-file" data-path="${path}">×</button>
    `;
    
    fileEl.querySelector('.remove-file').addEventListener('click', () => {
      selectedFiles.delete(path);
      updateContextCount();
      renderFileTree(fileTree);
    });
    
    selectedFilesEl.appendChild(fileEl);
  });
}

// Render search results
function renderSearchResults(results) {
  const treeEl = document.getElementById('file-tree');
  treeEl.innerHTML = '';
  
  if (results.length === 0) {
    treeEl.innerHTML = '<p style="padding: 16px; color: var(--text-secondary);">No results found</p>';
    return;
  }
  
  results.forEach(file => {
    const item = document.createElement('div');
    item.className = 'file-item';
    item.innerHTML = `
      <svg class="file-icon" viewBox="0 0 24 24" fill="currentColor">
        <path d="M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z"/>
      </svg>
      <span class="file-name">${file.path}</span>
    `;
    
    item.addEventListener('click', () => {
      if (selectedFiles.has(file.path)) {
        selectedFiles.delete(file.path);
        item.classList.remove('selected');
      } else {
        selectedFiles.add(file.path);
        item.classList.add('selected');
      }
      updateContextCount();
    });
    
    treeEl.appendChild(item);
  });
}

// Event listeners
document.getElementById('connect-btn').addEventListener('click', () => {
  if (isConnected) {
    // TODO: Implement disconnect
    console.log('[ULAB Panel] Disconnect requested');
  } else {
    backgroundPort.postMessage({ type: 'connect_agent' });
  }
});

document.getElementById('select-project-btn').addEventListener('click', () => {
  backgroundPort.postMessage({
    type: 'agent_action',
    data: {
      action: 'project.select'
    }
  });
});

document.getElementById('build-context-btn').addEventListener('click', () => {
  if (selectedFiles.size === 0) {
    alert('Please select at least one file');
    return;
  }
  
  backgroundPort.postMessage({
    type: 'agent_action',
    data: {
      action: 'context.build',
      files: Array.from(selectedFiles)
    }
  });
});

// Search functionality
let searchTimeout = null;
document.getElementById('search-input').addEventListener('input', (e) => {
  clearTimeout(searchTimeout);
  
  const query = e.target.value.trim();
  
  if (query.length === 0) {
    renderFileTree(fileTree);
    return;
  }
  
  searchTimeout = setTimeout(() => {
    backgroundPort.postMessage({
      type: 'agent_action',
      data: {
        action: 'files.search',
        query: query
      }
    });
  }, 300);
});

// Initialize
connectToBackground();

console.log('[ULAB Panel] Side panel initialized');
