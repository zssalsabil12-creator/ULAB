// Universal Local AI Bridge - Background Service Worker
// Handles native messaging with local agent and side panel communication

const NATIVE_HOST_NAME = 'com.ulab.agent';

let port = null;
let isConnected = false;
let sidePanelPort = null;

// Connect to native messaging host
function connectToNativeHost() {
  try {
    port = chrome.runtime.connectNative(NATIVE_HOST_NAME);
    
    port.onMessage.addListener((message) => {
      console.log('[ULAB] Message from native host:', message);
      isConnected = true;
      
      // Forward to side panel if open
      if (sidePanelPort) {
        sidePanelPort.postMessage({
          type: 'agent_message',
          data: message
        });
      }
    });
    
    port.onDisconnect.addListener(() => {
      console.log('[ULAB] Disconnected from native host');
      isConnected = false;
      port = null;
      
      if (sidePanelPort) {
        sidePanelPort.postMessage({
          type: 'agent_disconnected'
        });
      }
    });
    
    console.log('[ULAB] Connected to native host');
    return true;
  } catch (error) {
    console.error('[ULAB] Failed to connect to native host:', error);
    return false;
  }
}

// Send message to native host
function sendToNativeHost(message) {
  if (!port || !isConnected) {
    console.error('[ULAB] Not connected to native host');
    return false;
  }
  
  try {
    port.postMessage(message);
    return true;
  } catch (error) {
    console.error('[ULAB] Failed to send message:', error);
    return false;
  }
}

// Handle messages from side panel
chrome.runtime.onConnect.addListener((p) => {
  if (p.name === 'sidepanel') {
    sidePanelPort = p;
    
    p.onMessage.addListener((message) => {
      console.log('[ULAB] Message from side panel:', message);
      
      if (message.type === 'connect_agent') {
        connectToNativeHost();
      } else if (message.type === 'agent_action') {
        sendToNativeHost(message.data);
      } else if (message.type === 'get_status') {
        p.postMessage({
          type: 'status',
          isConnected: isConnected
        });
      }
    });
    
    p.onDisconnect.addListener(() => {
      sidePanelPort = null;
    });
  }
});

// Handle extension icon click - open side panel
chrome.action.onClicked.addListener((tab) => {
  chrome.sidePanel.open({ windowId: tab.windowId });
});

// Set side panel behavior
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });

// Handle installation
chrome.runtime.onInstalled.addListener((details) => {
  console.log('[ULAB] Extension installed:', details.reason);
  
  if (details.reason === 'install') {
    // First installation
    chrome.storage.local.set({
      projects: [],
      permissions: {},
      preferences: {
        theme: 'dark',
        language: 'en'
      }
    });
  }
});

console.log('[ULAB] Background service worker initialized');
