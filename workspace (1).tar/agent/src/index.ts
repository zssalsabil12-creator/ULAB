#!/usr/bin/env node

/**
 * Universal Local AI Bridge - Local Agent
 * 
 * This agent runs locally on the user's Windows machine and provides
 * secure file system access to the Chrome extension via Native Messaging.
 */

import * as fs from 'fs';
import * as path from 'path';
import * as readline from 'readline';

// Configuration
const CONFIG = {
  allowedProjectPaths: new Set<string>(),
  sensitivePatterns: [
    /\.env$/,
    /\.pem$/,
    /\.key$/,
    /private.*key/i,
    /credential/i,
    /secret/i,
  ],
  ignoredPatterns: [
    /node_modules/,
    /\.git/,
    /dist/,
    /build/,
    /coverage/,
    /\.cache/,
  ],
  maxFileSize: 10 * 1024 * 1024, // 10MB
};

// Security utilities
function isPathAllowed(requestedPath: string): boolean {
  const normalizedPath = path.normalize(requestedPath);
  
  // Check if path is within any allowed project
  for (const allowedPath of CONFIG.allowedProjectPaths) {
    if (normalizedPath.startsWith(allowedPath)) {
      return true;
    }
  }
  
  return false;
}

function isSensitiveFile(filePath: string): boolean {
  return CONFIG.sensitivePatterns.some(pattern => pattern.test(filePath));
}

function isIgnoredFile(filePath: string): boolean {
  return CONFIG.ignoredPatterns.some(pattern => pattern.test(filePath));
}

function validatePath(requestedPath: string, projectRoot: string): string | null {
  // Normalize and resolve path
  const normalizedPath = path.normalize(requestedPath);
  const resolvedPath = path.resolve(projectRoot, normalizedPath);
  
  // Check for path traversal
  if (!resolvedPath.startsWith(projectRoot)) {
    return null;
  }
  
  // Check if sensitive
  if (isSensitiveFile(resolvedPath)) {
    return null;
  }
  
  return resolvedPath;
}

// File system operations
async function listFiles(dirPath: string, projectRoot: string): Promise<any[]> {
  const validatedPath = validatePath(dirPath, projectRoot);
  if (!validatedPath) {
    throw new Error('Path not allowed');
  }
  
  const items = await fs.promises.readdir(validatedPath, { withFileTypes: true });
  const result = [];
  
  for (const item of items) {
    if (isIgnoredFile(item.name)) {
      continue;
    }
    
    const itemPath = path.join(validatedPath, item.name);
    
    if (item.isDirectory()) {
      result.push({
        name: item.name,
        path: itemPath,
        type: 'directory',
        children: await listFiles(itemPath, projectRoot),
      });
    } else {
      const stats = await fs.promises.stat(itemPath);
      result.push({
        name: item.name,
        path: itemPath,
        type: 'file',
        size: stats.size,
      });
    }
  }
  
  return result;
}

async function readFile(filePath: string, projectRoot: string): Promise<string> {
  const validatedPath = validatePath(filePath, projectRoot);
  if (!validatedPath) {
    throw new Error('Path not allowed');
  }
  
  const stats = await fs.promises.stat(validatedPath);
  
  if (stats.size > CONFIG.maxFileSize) {
    throw new Error('File too large');
  }
  
  return await fs.promises.readFile(validatedPath, 'utf-8');
}

async function searchFiles(query: string, projectRoot: string): Promise<any[]> {
  const results = [];
  
  async function search(dirPath: string) {
    const items = await fs.promises.readdir(dirPath, { withFileTypes: true });
    
    for (const item of items) {
      const itemPath = path.join(dirPath, item.name);
      
      if (isIgnoredFile(itemPath)) {
        continue;
      }
      
      if (item.isDirectory()) {
        await search(itemPath);
      } else {
        if (item.name.toLowerCase().includes(query.toLowerCase())) {
          const stats = await fs.promises.stat(itemPath);
          results.push({
            name: item.name,
            path: itemPath,
            size: stats.size,
          });
        }
      }
    }
  }
  
  await search(projectRoot);
  return results;
}

async function writeFile(filePath: string, content: string, projectRoot: string): Promise<void> {
  const validatedPath = validatePath(filePath, projectRoot);
  if (!validatedPath) {
    throw new Error('Path not allowed');
  }
  
  await fs.promises.writeFile(validatedPath, content, 'utf-8');
}

// Message handling
let currentProject: string | null = null;

async function handleMessage(message: any): Promise<any> {
  try {
    const { action, data } = message;
    
    switch (action) {
      case 'project.select':
        // In a real implementation, this would show a folder picker
        // For now, we'll use a predefined path or ask via stdin
        if (data && data.path) {
          const projectPath = path.resolve(data.path);
          
          if (!fs.existsSync(projectPath)) {
            return { success: false, error: 'Path does not exist' };
          }
          
          CONFIG.allowedProjectPaths.add(projectPath);
          currentProject = projectPath;
          
          return {
            success: true,
            action: 'project.selected',
            data: {
              name: path.basename(projectPath),
              path: projectPath,
            },
          };
        }
        return { success: false, error: 'No path provided' };
      
      case 'files.list':
        if (!currentProject) {
          return { success: false, error: 'No project selected' };
        }
        const files = await listFiles(data?.path || currentProject, currentProject);
        return {
          success: true,
          action: 'files.list',
          data: files,
        };
      
      case 'files.read':
        if (!currentProject) {
          return { success: false, error: 'No project selected' };
        }
        const content = await readFile(data.path, currentProject);
        return {
          success: true,
          action: 'files.read',
          data: {
            path: data.path,
            content: content,
          },
        };
      
      case 'files.search':
        if (!currentProject) {
          return { success: false, error: 'No project selected' };
        }
        const results = await searchFiles(data.query, currentProject);
        return {
          success: true,
          action: 'search.results',
          data: results,
        };
      
      case 'files.write':
        if (!currentProject) {
          return { success: false, error: 'No project selected' };
        }
        await writeFile(data.path, data.content, currentProject);
        return {
          success: true,
          action: 'files.written',
          data: { path: data.path },
        };
      
      default:
        return { success: false, error: `Unknown action: ${action}` };
    }
  } catch (error) {
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error',
    };
  }
}

// Native Messaging protocol
// Chrome Native Messaging uses length-prefixed JSON messages
function readMessage(): Promise<any> {
  return new Promise((resolve) => {
    let chunks: Buffer[] = [];
    
    process.stdin.on('data', (chunk) => {
      chunks.push(chunk);
      
      const buffer = Buffer.concat(chunks);
      
      if (buffer.length >= 4) {
        const messageLength = buffer.readUInt32LE(0);
        
        if (buffer.length >= 4 + messageLength) {
          const messageData = buffer.slice(4, 4 + messageLength);
          const message = JSON.parse(messageData.toString('utf-8'));
          resolve(message);
        }
      }
    });
  });
}

function sendMessage(message: any): void {
  const messageData = Buffer.from(JSON.stringify(message), 'utf-8');
  const lengthBuffer = Buffer.alloc(4);
  lengthBuffer.writeUInt32LE(messageData.length, 0);
  
  process.stdout.write(lengthBuffer);
  process.stdout.write(messageData);
}

// Main loop
async function main() {
  console.error('[ULAB Agent] Local agent started');
  
  while (true) {
    try {
      const message = await readMessage();
      console.error('[ULAB Agent] Received message:', message);
      
      const response = await handleMessage(message);
      console.error('[ULAB Agent] Sending response:', response);
      
      sendMessage(response);
    } catch (error) {
      console.error('[ULAB Agent] Error:', error);
      sendMessage({
        success: false,
        error: 'Internal error',
      });
    }
  }
}

// Start the agent
main().catch((error) => {
  console.error('[ULAB Agent] Fatal error:', error);
  process.exit(1);
});
