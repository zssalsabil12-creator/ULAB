import { useState } from 'react';
import Landing from './pages/Landing';
import Workspace from './pages/Workspace';

export default function App() {
  const [view, setView] = useState<'landing' | 'workspace'>('landing');

  if (view === 'workspace') {
    return <Workspace onBack={() => setView('landing')} />;
  }

  return <Landing onLaunch={() => setView('workspace')} />;
}
