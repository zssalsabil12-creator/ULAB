import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Cpu, Play, Pause, CheckCircle, XCircle, AlertTriangle,
  FileCode, Terminal as TermIcon, GitBranch, ArrowRight,
  Shield, Eye, Zap, Clock, ChevronDown, ChevronUp
} from 'lucide-react';
import { parseULPCommands, parseFileModifications, generateDiff, ULPResponse, FileModification } from '../utils/ulpProtocol';

interface AgentAction {
  id: string;
  type: 'ulp_command' | 'file_modification' | 'info';
  status: 'pending' | 'approved' | 'denied' | 'executed' | 'failed';
  description: string;
  details?: any;
  timestamp: string;
}

interface AgentModePanelProps {
  aiResponse: string;
  fileContents: Record<string, string>;
  onExecuteCommand: (command: string, params: any) => Promise<any>;
  onApplyModification: (path: string, content: string) => Promise<boolean>;
}

export default function AgentModePanel({
  aiResponse,
  fileContents,
  onExecuteCommand,
  onApplyModification,
}: AgentModePanelProps) {
  const [actions, setActions] = useState<AgentAction[]>([]);
  const [isRunning, setIsRunning] = useState(false);
  const [autoApprove, setAutoApprove] = useState(false);
  const [expandedAction, setExpandedAction] = useState<string | null>(null);

  // Parse AI response and create actions
  const parseResponse = () => {
    const newActions: AgentAction[] = [];
    
    // Parse ULP commands
    const ulpCommands = parseULPCommands(aiResponse);
    ulpCommands.forEach((cmd, i) => {
      newActions.push({
        id: `ulp-${i}-${Date.now()}`,
        type: 'ulp_command',
        status: 'pending',
        description: `Execute: ${cmd.command}`,
        details: cmd,
        timestamp: new Date().toLocaleTimeString('ar-EG'),
      });
    });
    
    // Parse file modifications
    const modifications = parseFileModifications(aiResponse);
    modifications.forEach((mod, i) => {
      const existingContent = fileContents[mod.path] || '';
      const diff = existingContent ? generateDiff(existingContent, mod.content || '') : null;
      
      newActions.push({
        id: `mod-${i}-${Date.now()}`,
        type: 'file_modification',
        status: 'pending',
        description: `${mod.type === 'create' ? 'Create' : 'Modify'}: ${mod.path}`,
        details: { ...mod, diff },
        timestamp: new Date().toLocaleTimeString('ar-EG'),
      });
    });
    
    setActions(prev => [...prev, ...newActions]);
    return newActions;
  };

  const handleApprove = async (action: AgentAction) => {
    setActions(prev => prev.map(a => a.id === action.id ? { ...a, status: 'approved' } : a));
    
    try {
      if (action.type === 'ulp_command') {
        const result = await onExecuteCommand(action.details.command, action.details.data);
        setActions(prev => prev.map(a => a.id === action.id ? { ...a, status: 'executed' } : a));
      } else if (action.type === 'file_modification') {
        const success = await onApplyModification(action.details.path, action.details.content);
        setActions(prev => prev.map(a => a.id === action.id ? { 
          ...a, status: success ? 'executed' : 'failed' 
        } : a));
      }
    } catch (error) {
      setActions(prev => prev.map(a => a.id === action.id ? { ...a, status: 'failed' } : a));
    }
  };

  const handleDeny = (action: AgentAction) => {
    setActions(prev => prev.map(a => a.id === action.id ? { ...a, status: 'denied' } : a));
  };

  const handleApproveAll = async () => {
    setIsRunning(true);
    const pending = actions.filter(a => a.status === 'pending');
    for (const action of pending) {
      await handleApprove(action);
      await new Promise(r => setTimeout(r, 300));
    }
    setIsRunning(false);
  };

  const pendingCount = actions.filter(a => a.status === 'pending').length;
  const executedCount = actions.filter(a => a.status === 'executed').length;

  const getActionIcon = (action: AgentAction) => {
    if (action.type === 'ulp_command') {
      if (action.details?.command?.startsWith('files.')) return <FileCode className="w-4 h-4" />;
      if (action.details?.command?.startsWith('git.')) return <GitBranch className="w-4 h-4" />;
      if (action.details?.command?.startsWith('terminal.')) return <TermIcon className="w-4 h-4" />;
      return <Zap className="w-4 h-4" />;
    }
    return <FileCode className="w-4 h-4" />;
  };

  const getStatusColor = (status: AgentAction['status']) => {
    switch (status) {
      case 'pending': return 'text-yellow-400';
      case 'approved': return 'text-blue-400';
      case 'executed': return 'text-green-400';
      case 'denied': return 'text-red-400';
      case 'failed': return 'text-red-400';
    }
  };

  const getStatusIcon = (status: AgentAction['status']) => {
    switch (status) {
      case 'pending': return <Clock className="w-3 h-3" />;
      case 'approved': return <ArrowRight className="w-3 h-3" />;
      case 'executed': return <CheckCircle className="w-3 h-3" />;
      case 'denied': return <XCircle className="w-3 h-3" />;
      case 'failed': return <AlertTriangle className="w-3 h-3" />;
    }
  };

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="p-3 border-b border-[#2a2a3a] flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-500/20 to-pink-500/20 flex items-center justify-center">
            <Cpu className="w-4 h-4 text-purple-400" />
          </div>
          <div>
            <h3 className="text-sm font-bold">Agent Mode</h3>
            <p className="text-[10px] text-[#94a3b8]">AI يعمل كوكيل محلي</p>
          </div>
        </div>
        <div className="flex items-center gap-1">
          {pendingCount > 0 && (
            <span className="px-1.5 py-0.5 rounded text-[9px] bg-yellow-500/20 text-yellow-300">
              {pendingCount} pending
            </span>
          )}
          {executedCount > 0 && (
            <span className="px-1.5 py-0.5 rounded text-[9px] bg-green-500/20 text-green-300">
              {executedCount} done
            </span>
          )}
        </div>
      </div>

      {/* Controls */}
      <div className="p-2 border-b border-[#2a2a3a] flex items-center gap-2">
        <button
          onClick={parseResponse}
          disabled={!aiResponse || isRunning}
          className="flex-1 flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-purple-500 to-pink-500 text-white text-xs font-medium disabled:opacity-50 transition-opacity"
        >
          <Eye className="w-3 h-3" />
          تحليل رد AI
        </button>
        {pendingCount > 0 && (
          <button
            onClick={handleApproveAll}
            disabled={isRunning}
            className="flex items-center justify-center gap-1 px-3 py-1.5 rounded-lg bg-green-500/20 text-green-300 text-xs font-medium hover:bg-green-500/30 disabled:opacity-50 transition-colors"
          >
            {isRunning ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
            موافقة على الكل
          </button>
        )}
      </div>

      {/* Auto-approve toggle */}
      <div className="px-3 py-2 border-b border-[#2a2a3a] flex items-center justify-between">
        <span className="text-[10px] text-[#94a3b8] flex items-center gap-1">
          <Shield className="w-3 h-3" />
          موافقة تلقائية (للملفات الآمنة فقط)
        </span>
        <button
          onClick={() => setAutoApprove(!autoApprove)}
          className={`w-8 h-4 rounded-full transition-colors ${autoApprove ? 'bg-purple-500' : 'bg-[#2a2a3a]'}`}
        >
          <div className={`w-3 h-3 rounded-full bg-white transition-transform ${autoApprove ? 'translate-x-4' : 'translate-x-0.5'}`}></div>
        </button>
      </div>

      {/* Actions List */}
      <div className="flex-1 overflow-y-auto p-2 space-y-2">
        {actions.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center p-6">
            <Cpu className="w-12 h-12 text-[#2a2a3a] mb-3" />
            <p className="text-xs text-[#94a3b8] mb-2">لا توجد إجراءات</p>
            <p className="text-[10px] text-[#64748b]">
              الصق رد AI هنا أو اكتب ردًا يحتوي على أوامر ULP
            </p>
            <div className="mt-4 p-2 rounded bg-[#0a0a0f] border border-[#2a2a3a] w-full">
              <p className="text-[9px] text-[#64748b] mb-1">مثال على أمر ULP:</p>
              <code className="text-[9px] text-indigo-300 font-mono" dir="ltr">
                ```ulp<br/>
                {`{ "command": "files.read", "params": { "path": "src/auth/login.ts" } }`}
                <br/>```
              </code>
            </div>
          </div>
        ) : (
          <AnimatePresence>
            {actions.map(action => (
              <motion.div
                key={action.id}
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="p-2 rounded-lg bg-[#0a0a0f] border border-[#2a2a3a]"
              >
                <div className="flex items-start gap-2">
                  <div className={`mt-0.5 ${getStatusColor(action.status)}`}>
                    {getActionIcon(action)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5 mb-0.5">
                      <span className="text-xs font-medium text-[#e2e8f0] truncate">
                        {action.description}
                      </span>
                      <span className={`flex items-center gap-0.5 text-[9px] ${getStatusColor(action.status)}`}>
                        {getStatusIcon(action.status)}
                      </span>
                    </div>
                    <p className="text-[9px] text-[#64748b]">{action.timestamp}</p>
                    
                    {/* Expandable details */}
                    {action.details && (
                      <div className="mt-1">
                        <button
                          onClick={() => setExpandedAction(expandedAction === action.id ? null : action.id)}
                          className="text-[9px] text-indigo-400 hover:text-indigo-300 flex items-center gap-0.5"
                        >
                          {expandedAction === action.id ? <ChevronUp className="w-2.5 h-2.5" /> : <ChevronDown className="w-2.5 h-2.5" />}
                          التفاصيل
                        </button>
                        {expandedAction === action.id && (
                          <motion.div
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            className="mt-1 p-1.5 rounded bg-[#111118] text-[9px] font-mono text-[#94a3b8] overflow-x-auto"
                            dir="ltr"
                          >
                            <pre>{JSON.stringify(action.details, null, 2)}</pre>
                          </motion.div>
                        )}
                      </div>
                    )}

                    {/* Diff preview for file modifications */}
                    {action.type === 'file_modification' && action.details?.diff && (
                      <div className="mt-1 p-1.5 rounded bg-[#111118] text-[9px] font-mono max-h-24 overflow-y-auto">
                        {action.details.diff.slice(0, 10).map((change: any, i: number) => (
                          <div key={i} className={
                            change.type === 'add' ? 'text-green-400' :
                            change.type === 'remove' ? 'text-red-400' :
                            'text-[#64748b]'
                          }>
                            {change.type === 'add' ? '+ ' : change.type === 'remove' ? '- ' : '  '}
                            {change.line}
                          </div>
                        ))}
                        {action.details.diff.length > 10 && (
                          <p className="text-[#64748b]">... +{action.details.diff.length - 10} more lines</p>
                        )}
                      </div>
                    )}
                  </div>
                </div>

                {/* Action buttons */}
                {action.status === 'pending' && (
                  <div className="flex items-center gap-1.5 mt-2 pt-2 border-t border-[#2a2a3a]">
                    <button
                      onClick={() => handleApprove(action)}
                      className="flex-1 flex items-center justify-center gap-1 px-2 py-1 rounded bg-green-500/20 text-green-300 text-[10px] hover:bg-green-500/30 transition-colors"
                    >
                      <CheckCircle className="w-3 h-3" />
                      موافقة
                    </button>
                    <button
                      onClick={() => handleDeny(action)}
                      className="flex-1 flex items-center justify-center gap-1 px-2 py-1 rounded bg-red-500/20 text-red-300 text-[10px] hover:bg-red-500/30 transition-colors"
                    >
                      <XCircle className="w-3 h-3" />
                      رفض
                    </button>
                  </div>
                )}
              </motion.div>
            ))}
          </AnimatePresence>
        )}
      </div>

      {/* Footer */}
      <div className="p-2 border-t border-[#2a2a3a] flex items-center justify-between text-[9px] text-[#64748b]">
        <span className="flex items-center gap-1">
          <Shield className="w-3 h-3 text-green-400" />
          كل العمليات محلية
        </span>
        <span>{actions.length} إجراءات</span>
      </div>
    </div>
  );
}
