import { useState, useCallback, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  FolderTree, Search, FileCode, Settings as SettingsIcon, ChevronDown, ChevronLeft,
  X, Folder, File, Eye, Shield, Terminal, GitBranch, Sparkles,
  Copy, Check, ArrowLeft, Zap, Brain, Layers, Clock, 
  AlertTriangle, CheckCircle, Play, Square, Send, RotateCcw,
  Maximize2, Minimize2, Plus, Trash2, RefreshCw, Download,
  ArrowUp, ArrowDown, Cpu, Globe, Lock, Unlock
} from 'lucide-react';
import {
  FileNode, ProjectIndex, readDirectory, readFileContent,
  findFileHandle, flattenTree, buildIndex, formatFileSize,
  getFileIcon, shouldIgnore
} from '../utils/fileSystem';
import {
  extractContext, generateContextString, searchInContent,
  expandKeywords, extractKeywords, ContextResult
} from '../utils/contextEngine';
import ProjectMap from '../components/ProjectMap';
import AIComparison from '../components/AIComparison';
import AIBridgePanel from '../components/AIBridgePanel';
import AgentModePanel from '../components/AgentModePanel';
import LocalMemoryPanel from '../components/LocalMemoryPanel';
import PermissionCenter, { DEFAULT_CONFIG as DEFAULT_PERMISSION_CONFIG } from '../components/PermissionCenter';
import ApprovalModal, { ApprovalAction } from '../components/ApprovalModal';
import TaskHistory, { Task } from '../components/TaskHistory';
import ContextBuilder from '../components/ContextBuilder';
import DiffViewer from '../components/DiffViewer';
import WelcomeModal from '../components/WelcomeModal';
import NotificationSystem, { useNotifications } from '../components/NotificationSystem';
import KeyboardShortcutsModal from '../components/KeyboardShortcutsModal';
import OperationLog from '../components/OperationLog';
import GitPanel, { DEMO_GIT_INFO } from '../components/GitPanel';
import TerminalPanel from '../components/TerminalPanel';
import SettingsPanel, { DEFAULT_SETTINGS } from '../components/SettingsPanel';
import { createDemoIndex, DEMO_FILE_CONTENTS } from '../utils/demoData';
import { loadMemory, getProjectMemory, saveMemory, generateMemoryContext, ProjectMemory } from '../utils/localMemory';
import { validatePath, validateCommand, detectPromptInjection, validateAction, logAudit } from '../utils/securityEngine';
import { localAgent, useAgentConnection } from '../utils/localAgent';
import { PROVIDERS, detectCurrentProvider } from '../utils/providerAdapters';

// ============ FILE TREE COMPONENT ============
function FileTreeItem({ 
  node, depth, selectedPath, onSelect, onToggle, onReadFile 
}: { 
  node: FileNode; depth: number; selectedPath: string | null;
  onSelect: (path: string) => void; onToggle: (path: string) => void;
  onReadFile: (path: string) => void;
}) {
  const isSelected = selectedPath === node.path;
  const isDir = node.type === 'directory';

  return (
    <div>
      <div
        onClick={() => {
          if (isDir) onToggle(node.path);
          else { onSelect(node.path); onReadFile(node.path); }
        }}
        className={`flex items-center gap-1.5 py-1 px-2 cursor-pointer text-xs rounded transition-colors ${
          isSelected ? 'bg-indigo-500/20 text-indigo-300' : 'text-[#94a3b8] hover:bg-[#252530] hover:text-white'
        }`}
        style={{ paddingRight: `${depth * 12 + 8}px` }}
      >
        {isDir ? (
          <ChevronDown className={`w-3 h-3 transition-transform flex-shrink-0 ${node.isExpanded ? '' : '-rotate-90'}`} />
        ) : (
          <span className="w-3 h-3 flex-shrink-0 text-center text-[10px]">{getFileIcon(node.name, 'file')}</span>
        )}
        <span className="truncate">{node.name}</span>
        {node.type === 'file' && node.size !== undefined && (
          <span className="text-[10px] text-[#64748b] mr-auto">{formatFileSize(node.size)}</span>
        )}
      </div>
      {isDir && node.isExpanded && node.children && (
        <div>
          {node.children.map(child => (
            <FileTreeItem
              key={child.path}
              node={child}
              depth={depth + 1}
              selectedPath={selectedPath}
              onSelect={onSelect}
              onToggle={onToggle}
              onReadFile={onReadFile}
            />
          ))}
        </div>
      )}
    </div>
  );
}

// ============ CODE VIEWER ============
function CodeViewer({ content, filename }: { content: string; filename: string }) {
  const lines = content.split('\n');
  const ext = filename.split('.').pop()?.toLowerCase() || '';
  
  const highlightLine = (line: string): JSX.Element => {
    if (['ts', 'tsx', 'js', 'jsx', 'py', 'go', 'rs', 'java'].includes(ext)) {
      // Simple syntax highlighting
      let html = line
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
      
      // Comments
      html = html.replace(/(\/\/.*$|#.*$)/gm, '<span class="syntax-comment">$1</span>');
      // Strings
      html = html.replace(/(["'`])(?:(?!\1).)*\1/g, '<span class="syntax-string">$&</span>');
      // Keywords
      const keywords = ['const', 'let', 'var', 'function', 'return', 'if', 'else', 'for', 'while', 'class', 'import', 'export', 'from', 'default', 'async', 'await', 'def', 'self', 'None', 'True', 'False', 'fn', 'pub', 'struct', 'impl', 'use', 'mod', 'interface', 'type', 'extends', 'implements'];
      keywords.forEach(kw => {
        const regex = new RegExp(`\\b(${kw})\\b`, 'g');
        html = html.replace(regex, '<span class="syntax-keyword">$1</span>');
      });
      // Numbers
      html = html.replace(/\b(\d+\.?\d*)\b/g, '<span class="syntax-number">$1</span>');
      
      return <span dangerouslySetInnerHTML={{ __html: html || ' ' }} />;
    }
    return <span>{line || ' '}</span>;
  };
  
  return (
    <div className="code-block h-full overflow-auto bg-[#0a0a0f] rounded-lg">
      <div className="sticky top-0 bg-[#0a0a0f] border-b border-[#2a2a3a] px-4 py-2 flex items-center gap-2 z-10">
        <FileCode className="w-4 h-4 text-indigo-400" />
        <span className="text-xs text-[#94a3b8]">{filename}</span>
        <span className="text-[10px] text-[#64748b] mr-auto">{lines.length} lines • {ext.toUpperCase()}</span>
      </div>
      <div className="p-4">
        {lines.map((line, i) => (
          <div key={i} className="flex hover:bg-[#111118] group">
            <span className="w-10 text-right text-[#4a5568] text-xs select-none flex-shrink-0 pr-3 group-hover:text-[#94a3b8]">
              {i + 1}
            </span>
            <span className="text-xs text-[#e2e8f0] whitespace-pre overflow-x-auto">
              {highlightLine(line)}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ============ CONTEXT PANEL ============
function ContextPanel({ 
  context, onCopyContext, onExportContext, isCopied 
}: { 
  context: ContextResult | null; onCopyContext: () => void; onExportContext: () => void; isCopied: boolean;
}) {
  if (!context) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center p-6">
        <Brain className="w-12 h-12 text-[#2a2a3a] mb-4" />
        <p className="text-sm text-[#94a3b8]">اكتب استعلامًا لاستخراج السياق</p>
        <p className="text-xs text-[#64748b] mt-2">سيقوم المحرك بتحليل مشروعك وإيجاد الملفات الأكثر صلة</p>
      </div>
    );
  }

  return (
    <div className="p-4 space-y-4 overflow-y-auto h-full">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-bold flex items-center gap-2">
          <Layers className="w-4 h-4 text-cyan-400" />
          السياق المستخرج
        </h3>
        <div className="flex items-center gap-1">
          <button onClick={onExportContext} className="flex items-center gap-1 px-2 py-1 rounded text-xs bg-[#252530] hover:bg-[#2a2a3a] transition-colors" title="تصدير كملف">
            <Download className="w-3 h-3" />
          </button>
          <button onClick={onCopyContext} className="flex items-center gap-1 px-2 py-1 rounded text-xs bg-[#252530] hover:bg-[#2a2a3a] transition-colors">
            {isCopied ? <Check className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3" />}
            {isCopied ? 'تم' : 'نسخ'}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-2">
        <div className="p-2 rounded bg-[#0a0a0f] text-center">
          <p className="text-lg font-bold text-indigo-400">{context.files.length}</p>
          <p className="text-[10px] text-[#94a3b8]">ملفات</p>
        </div>
        <div className="p-2 rounded bg-[#0a0a0f] text-center">
          <p className="text-lg font-bold text-cyan-400">~{context.totalLines}</p>
          <p className="text-[10px] text-[#94a3b8]">سطر</p>
        </div>
        <div className="p-2 rounded bg-[#0a0a0f] text-center">
          <p className="text-lg font-bold text-purple-400">~{context.estimatedTokens}</p>
          <p className="text-[10px] text-[#94a3b8]">token</p>
        </div>
      </div>

      <div>
        <p className="text-xs text-[#94a3b8] mb-2">الكلمات المفتاحية:</p>
        <div className="flex flex-wrap gap-1">
          {context.keywords.slice(0, 12).map(kw => (
            <span key={kw} className="px-1.5 py-0.5 rounded text-[10px] bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
              {kw}
            </span>
          ))}
        </div>
      </div>

      <div>
        <p className="text-xs text-[#94a3b8] mb-2">الملفات المختارة:</p>
        <div className="space-y-1.5">
          {context.files.map((file, i) => (
            <div key={i} className="p-2 rounded bg-[#0a0a0f] border border-[#2a2a3a]">
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono text-cyan-400">{getFileIcon(file.path.split('/').pop() || '', 'file')}</span>
                <span className="text-xs text-[#e2e8f0] truncate font-mono" dir="ltr">{file.path}</span>
              </div>
              <div className="flex items-center gap-2 mt-1">
                <div className="flex-1 h-1 rounded bg-[#252530] overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-indigo-500 to-cyan-500 rounded" style={{ width: `${Math.min(file.relevance * 5, 100)}%` }}></div>
                </div>
                <span className="text-[10px] text-[#94a3b8]">{file.relevance}</span>
              </div>
              <p className="text-[10px] text-[#64748b] mt-1">{file.reason}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ============ CHAT PANEL ============
function ChatPanel({ 
  onExtractContext, isLoading, onAiResponse 
}: { 
  onExtractContext: (query: string) => void; isLoading: boolean;
  onAiResponse?: (response: string) => void;
}) {
  const [messages, setMessages] = useState<{ role: 'user' | 'system'; content: string }[]>([
    { role: 'system', content: 'مرحبًا! اكتب سؤالك عن المشروع وسأستخرج السياق المناسب من ملفاتك المحلية.' }
  ]);
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = () => {
    if (!input.trim() || isLoading) return;
    setMessages(prev => [...prev, { role: 'user', content: input }]);
    onExtractContext(input);
    setInput('');
  };

  const suggestions = [
    'أين يتم التحقق من المصادقة؟',
    'Find authentication logic',
    'Show API routes',
    'اشرح بنية المشروع',
    'Find database models',
    'Show component hierarchy',
    'ما هي الملفات المرتبطة بـ login؟',
    'Find all React components',
    'Show me the database schema',
    'أين يتم التعامل مع الأخطاء؟',
  ];

  return (
    <div className="flex flex-col h-full">
      <div className="p-3 border-b border-[#2a2a3a] flex items-center gap-2">
        <Sparkles className="w-4 h-4 text-indigo-400" />
        <span className="text-sm font-bold">Local AI Assistant</span>
      </div>
      
      <div className="flex-1 overflow-y-auto p-3 space-y-3">
        {messages.map((msg, i) => (
          <div key={i} className={`flex ${msg.role === 'user' ? 'justify-start' : 'justify-end'}`}>
            <div className={`max-w-[85%] p-2.5 rounded-lg text-xs ${
              msg.role === 'user' 
                ? 'bg-indigo-500/10 border border-indigo-500/20 text-[#e2e8f0]' 
                : 'bg-[#252530] border border-[#2a2a3a] text-[#94a3b8]'
            }`}>
              {msg.content}
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-end">
            <div className="bg-[#252530] border border-[#2a2a3a] rounded-lg p-2.5 text-xs text-[#94a3b8]">
              <span className="flex items-center gap-2">
                <RefreshCw className="w-3 h-3 animate-spin" />
                جاري تحليل المشروع...
              </span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Suggestions */}
      {messages.length <= 1 && (
        <div className="px-3 pb-2">
          <p className="text-[10px] text-[#64748b] mb-1.5">اقتراحات:</p>
          <div className="flex flex-wrap gap-1">
            {suggestions.map((s, i) => (
              <button key={i} onClick={() => { setInput(s); }} className="px-2 py-1 rounded text-[10px] bg-[#252530] hover:bg-[#2a2a3a] text-[#94a3b8] transition-colors">
                {s}
              </button>
            ))}
          </div>
        </div>
      )}

      <div className="p-3 border-t border-[#2a2a3a] space-y-2">
        <div className="flex gap-2">
          <input
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleSend()}
            placeholder="اكتب سؤالك عن المشروع..."
            className="flex-1 px-3 py-2 rounded-lg bg-[#0a0a0f] border border-[#2a2a3a] text-xs text-white placeholder:text-[#64748b] focus:border-indigo-500/50 focus:outline-none"
            dir="auto"
          />
          <button
            onClick={handleSend}
            disabled={!input.trim() || isLoading}
            className="px-3 py-2 rounded-lg bg-gradient-to-r from-indigo-500 to-cyan-500 text-white disabled:opacity-50 transition-opacity"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
        {onAiResponse && (
          <button
            onClick={async () => {
              const text = await navigator.clipboard.readText();
              if (text) onAiResponse(text);
            }}
            className="w-full flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg bg-purple-500/10 border border-purple-500/20 text-purple-300 text-[10px] hover:bg-purple-500/20 transition-colors"
          >
            <Cpu className="w-3 h-3" />
            لصق رد AI (للوكيل)
          </button>
        )}
      </div>
    </div>
  );
}

// ============ PERMISSION MODAL ============
function PermissionModal({ 
  isOpen, onClose, mode, onModeChange 
}: { 
  isOpen: boolean; onClose: () => void; mode: string; onModeChange: (m: string) => void;
}) {
  if (!isOpen) return null;
  
  const modes = [
    { id: 'readonly', name: 'قراءة فقط', icon: <Eye className="w-5 h-5" />, color: 'green', desc: 'AI يقرأ ويحلل فقط' },
    { id: 'assisted', name: 'كتابة بمساعدة', icon: <FileCode className="w-5 h-5" />, color: 'yellow', desc: 'AI يقترح والتوافق أنت' },
    { id: 'agent', name: 'وضع الوكيل', icon: <Cpu className="w-5 h-5" />, color: 'purple', desc: 'AI ينفذ بعد موافقتك' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm" onClick={onClose}>
      <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="bg-[#111118] border border-[#2a2a3a] rounded-xl p-6 w-full max-w-md mx-4" onClick={e => e.stopPropagation()}>
        <div className="flex items-center gap-2 mb-6">
          <Shield className="w-5 h-5 text-indigo-400" />
          <h3 className="text-lg font-bold">نظام الصلاحيات</h3>
          <button onClick={onClose} className="mr-auto text-[#94a3b8] hover:text-white"><X className="w-5 h-5" /></button>
        </div>
        <div className="space-y-3">
          {modes.map(m => (
            <button
              key={m.id}
              onClick={() => onModeChange(m.id)}
              className={`w-full p-4 rounded-lg border text-right transition-all ${
                mode === m.id 
                  ? `border-${m.color}-500/50 bg-${m.color}-500/10` 
                  : 'border-[#2a2a3a] hover:border-[#3a3a4a]'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className={`text-${m.color}-400`}>{m.icon}</div>
                <div>
                  <p className="text-sm font-bold">{m.name}</p>
                  <p className="text-xs text-[#94a3b8]">{m.desc}</p>
                </div>
                {mode === m.id && <CheckCircle className={`w-5 h-5 text-${m.color}-400 mr-auto`} />}
              </div>
            </button>
          ))}
        </div>
        <div className="mt-6 p-3 rounded-lg bg-[#0a0a0f] border border-[#2a2a3a]">
          <div className="flex items-center gap-2 text-xs text-[#94a3b8]">
            <Lock className="w-3 h-3 text-green-400" />
            <span>جميع العمليات تُسجل محليًا ولا تُرسل لأي خادم</span>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

// ============ SEARCH PANEL ============
function SearchPanel({ 
  index, onFileSelect, fileContents 
}: { 
  index: ProjectIndex | null; onFileSelect: (path: string) => void;
  fileContents: Record<string, string>;
}) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<{ file: string; line: number; text: string }[]>([]);

  useEffect(() => {
    if (!query.trim() || !index) { setResults([]); return; }
    
    const allResults: { file: string; line: number; text: string }[] = [];
    const q = query.toLowerCase();
    
    // Search in filenames first
    for (const file of index.flatFiles) {
      if (file.path.toLowerCase().includes(q)) {
        allResults.push({ file: file.path, line: 0, text: `📄 ${file.name} (اسم الملف)` });
      }
    }
    
    // Search in file contents
    for (const [path, content] of Object.entries(fileContents)) {
      const matches = searchInContent(content, query);
      for (const match of matches) {
        allResults.push({ file: path, line: match.line, text: match.text });
      }
    }
    
    setResults(allResults.slice(0, 30));
  }, [query, index, fileContents]);

  return (
    <div className="p-3 h-full flex flex-col">
      <div className="relative mb-3">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#64748b]" />
        <input
          value={query}
          onChange={e => setQuery(e.target.value)}
          placeholder="ابحث في المشروع..."
          className="w-full pr-9 pl-3 py-2 rounded-lg bg-[#0a0a0f] border border-[#2a2a3a] text-xs text-white placeholder:text-[#64748b] focus:border-indigo-500/50 focus:outline-none"
          dir="auto"
        />
      </div>
      <div className="flex-1 overflow-y-auto space-y-1">
        {results.length === 0 && query && (
          <p className="text-xs text-[#64748b] text-center py-4">لا توجد نتائج</p>
        )}
        {results.map((r, i) => (
          <button
            key={i}
            onClick={() => onFileSelect(r.file)}
            className="w-full text-right p-2 rounded hover:bg-[#252530] transition-colors"
          >
            <p className="text-[10px] text-indigo-400 font-mono truncate" dir="ltr">{r.file}</p>
            {r.line > 0 && (
              <>
                <p className="text-xs text-[#e2e8f0] truncate mt-0.5" dir="ltr">{r.text}</p>
                <p className="text-[10px] text-[#64748b]">سطر {r.line}</p>
              </>
            )}
          </button>
        ))}
        {!query && (
          <div className="text-center py-8">
            <Search className="w-8 h-8 text-[#2a2a3a] mx-auto mb-2" />
            <p className="text-xs text-[#64748b]">اكتب للبحث في الملفات والمحتوى</p>
          </div>
        )}
      </div>
    </div>
  );
}

// ============ MAIN WORKSPACE ============
export default function Workspace({ onBack }: { onBack: () => void }) {
  const [dirHandle, setDirHandle] = useState<FileSystemDirectoryHandle | null>(null);
  const [projectIndex, setProjectIndex] = useState<ProjectIndex | null>(null);
  const [selectedFile, setSelectedFile] = useState<string | null>(null);
  const [fileContent, setFileContent] = useState<string>('');
  const [fileContents, setFileContents] = useState<Record<string, string>>({});
  const [context, setContext] = useState<ContextResult | null>(null);
  const [isContextLoading, setIsContextLoading] = useState(false);
  const [isIndexing, setIsIndexing] = useState(false);
  const [activePanel, setActivePanel] = useState<'files' | 'search' | 'context' | 'chat' | 'map' | 'compare' | 'bridge' | 'agent' | 'memory' | 'permissions' | 'tasks' | 'contextBuilder' | 'log' | 'git' | 'terminal' | 'settings'>('chat');
  const [lastQuery, setLastQuery] = useState('');
  const [settings, setSettings] = useState(DEFAULT_SETTINGS);
  const [aiResponse, setAiResponse] = useState('');
  const [allMemory, setAllMemory] = useState<Record<string, ProjectMemory>>(loadMemory());
  const [permissionConfig, setPermissionConfig] = useState(DEFAULT_PERMISSION_CONFIG);
  const [pendingApproval, setPendingApproval] = useState<ApprovalAction | null>(null);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [showWelcome, setShowWelcome] = useState(true);
  const [showShortcuts, setShowShortcuts] = useState(false);
  const [selectedContextFiles, setSelectedContextFiles] = useState<string[]>([]);
  const [pinnedContextFiles, setPinnedContextFiles] = useState<string[]>([]);
  const [excludedContextPaths, setExcludedContextPaths] = useState<string[]>([]);
  const notifications = useNotifications();
  const agentConnection = useAgentConnection();
  const [permissionMode, setPermissionMode] = useState('readonly');
  const [showPermissions, setShowPermissions] = useState(false);
  const [isCopied, setIsCopied] = useState(false);
  const [sidebarWidth, setSidebarWidth] = useState(280);
  const [rightPanelWidth, setRightPanelWidth] = useState(320);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [operationLog, setOperationLog] = useState<{ time: string; action: string; detail: string }[]>([]);

  const addLog = (action: string, detail: string) => {
    setOperationLog(prev => [{ time: new Date().toLocaleTimeString('ar-EG'), action, detail }, ...prev].slice(0, 50));
  };

  // Get current project memory
  const currentProjectMemory = projectIndex
    ? getProjectMemory(allMemory, projectIndex.rootName, projectIndex.rootName)
    : null;

  // Update project memory
  const handleUpdateMemory = (updatedMemory: ProjectMemory) => {
    const newAllMemory = { ...allMemory, [updatedMemory.projectId]: updatedMemory };
    setAllMemory(newAllMemory);
    saveMemory(newAllMemory);
    addLog('تحديث الذاكرة', updatedMemory.projectId);
  };

  // Add task
  const addTask = (task: Omit<Task, 'id' | 'startedAt'>) => {
    const newTask: Task = {
      ...task,
      id: `task-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      startedAt: Date.now(),
    };
    setTasks(prev => [newTask, ...prev]);
    return newTask.id;
  };

  // Update task
  const updateTask = (id: string, updates: Partial<Task>) => {
    setTasks(prev => prev.map(t => t.id === id ? { ...t, ...updates } : t));
  };

  // Request approval
  const requestApproval = (action: Omit<ApprovalAction, 'id' | 'timestamp'>) => {
    const approvalAction: ApprovalAction = {
      ...action,
      id: `approval-${Date.now()}`,
      timestamp: Date.now(),
    };
    setPendingApproval(approvalAction);
  };

  // Start demo mode
  const handleStartDemo = () => {
    const demoIndex = createDemoIndex();
    setProjectIndex(demoIndex);
    setFileContents(DEMO_FILE_CONTENTS);
    addLog('وضع تجريبي', 'تم تحميل مشروع تجريبي');
  };

  // Open directory picker
  const handleOpenFolder = async () => {
    try {
      const handle = await (window as any).showDirectoryPicker({ mode: 'read' });
      setDirHandle(handle);
      setIsIndexing(true);
      addLog('فتح مجلد', handle.name);
      
      const files = await readDirectory(handle);
      const index = buildIndex(handle.name, files);
      setProjectIndex(index);
      setIsIndexing(false);
      addLog('فهرسة مكتملة', `${index.totalFiles} ملف, ${index.totalDirs} مجلد`);
    } catch (e: any) {
      if (e.name !== 'AbortError') {
        console.error(e);
        addLog('خطأ', e.message || 'فشل فتح المجلد');
      }
    }
  };

  // Toggle directory expansion
  const toggleDir = useCallback((path: string) => {
    if (!projectIndex) return;
    const toggle = (nodes: FileNode[]): FileNode[] => {
      return nodes.map(node => {
        if (node.path === path) return { ...node, isExpanded: !node.isExpanded };
        if (node.children) return { ...node, children: toggle(node.children) };
        return node;
      });
    };
    setProjectIndex({ ...projectIndex, files: toggle(projectIndex.files) });
  }, [projectIndex]);

  // Read file content
  const handleReadFile = useCallback(async (path: string) => {
    if (!dirHandle || fileContents[path]) return;
    try {
      const handle = await findFileHandle(dirHandle, path);
      if (handle && 'getFile' in handle) {
        const content = await readFileContent(handle as FileSystemFileHandle);
        setFileContents(prev => ({ ...prev, [path]: content }));
        setFileContent(content);
        addLog('قراءة ملف', path);
      }
    } catch (e) {
      console.error(e);
    }
  }, [dirHandle, fileContents]);

  // Select file
  const handleSelectFile = (path: string) => {
    setSelectedFile(path);
    if (fileContents[path]) {
      setFileContent(fileContents[path]);
    } else {
      handleReadFile(path);
    }
  };

  // Extract context
  const handleExtractContext = async (query: string) => {
    if (!projectIndex) return;
    setIsContextLoading(true);
    setLastQuery(query);
    addLog('استخراج سياق', query);
    
    // Simulate processing delay
    await new Promise(r => setTimeout(r, 800));
    
    const result = extractContext(projectIndex, query);
    setContext(result);
    
    // Load file contents for context files
    for (const file of result.files) {
      if (!fileContents[file.path]) {
        await handleReadFile(file.path);
      }
    }
    
    setIsContextLoading(false);
    setActivePanel('context');
    addLog('سياق مستخرج', `${result.files.length} ملفات, ~${result.estimatedTokens} tokens`);
  };

  // Copy context for AI
  const handleCopyContext = () => {
    if (!context) return;
    const contextStr = generateContextString(context, fileContents, lastQuery);
    navigator.clipboard.writeText(contextStr);
    setIsCopied(true);
    addLog('نسخ سياق', 'تم النسخ للحافظة');
    setTimeout(() => setIsCopied(false), 2000);
  };

  // Export context as file
  const handleExportContext = () => {
    if (!context) return;
    const contextStr = generateContextString(context, fileContents, lastQuery);
    const blob = new Blob([contextStr], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ulab-context-${Date.now()}.md`;
    a.click();
    URL.revokeObjectURL(url);
    addLog('تصدير سياق', 'تم التصدير كملف markdown');
  };

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey || e.metaKey) {
        switch (e.key) {
          case 'o':
            e.preventDefault();
            handleOpenFolder();
            break;
          case 'f':
            e.preventDefault();
            setActivePanel('search');
            break;
          case 'k':
            e.preventDefault();
            setActivePanel('search');
            break;
          case '1':
            e.preventDefault();
            setActivePanel('chat');
            break;
          case '2':
            e.preventDefault();
            setActivePanel('context');
            break;
          case '3':
            e.preventDefault();
            setActivePanel('compare');
            break;
        }
      }
      if (e.key === 'Escape') {
        setShowPermissions(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Check File System Access API support
  const isFSASupported = 'showDirectoryPicker' in window;

  return (
    <div className="h-screen flex flex-col bg-[#0a0a0f] overflow-hidden">
      {/* Header */}
      <header className="h-12 border-b border-[#2a2a3a] flex items-center px-4 gap-3 flex-shrink-0 bg-[#111118]">
        <button onClick={onBack} className="flex items-center gap-1 text-xs text-[#94a3b8] hover:text-white transition-colors">
          <ArrowLeft className="w-4 h-4" />
          <span className="hidden sm:inline">الرئيسية</span>
        </button>
        <div className="w-px h-5 bg-[#2a2a3a]"></div>
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded bg-gradient-to-br from-indigo-500 to-cyan-500 flex items-center justify-center">
            <Zap className="w-3.5 h-3.5 text-white" />
          </div>
          <span className="font-bold text-sm">ULAB Workspace</span>
        </div>
        
        {projectIndex && (
          <>
            <div className="w-px h-5 bg-[#2a2a3a]"></div>
            <div className="flex items-center gap-1.5 text-xs text-[#94a3b8]">
              <Folder className="w-3.5 h-3.5" />
              <span>{projectIndex.rootName}</span>
              {projectIndex.rootName === 'demo-project' && (
                <span className="px-1.5 py-0.5 rounded text-[9px] bg-yellow-500/10 text-yellow-300 border border-yellow-500/20">
                  تجريبي
                </span>
              )}
              <span className="text-[#64748b]">•</span>
              <span>{projectIndex.totalFiles} ملف</span>
            </div>
            <button
              onClick={() => { setProjectIndex(null); setSelectedFile(null); setFileContent(''); setFileContents({}); setContext(null); setOperationLog([]); }}
              className="text-[10px] text-[#64748b] hover:text-red-400 transition-colors"
              title="إغلاق المشروع"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </>
        )}

        <div className="flex items-center gap-2 mr-auto">
          {projectIndex && (
            <button onClick={() => setShowPermissions(true)} className="flex items-center gap-1 px-2 py-1 rounded text-xs bg-[#252530] hover:bg-[#2a2a3a] transition-colors">
              {permissionMode === 'readonly' ? <Lock className="w-3 h-3 text-green-400" /> : <Unlock className="w-3 h-3 text-yellow-400" />}
              <span className="hidden sm:inline">
                {permissionMode === 'readonly' ? 'قراءة فقط' : permissionMode === 'assisted' ? 'بمساعدة' : 'وكيل'}
              </span>
            </button>
          )}
          <button onClick={() => setShowShortcuts(true)} className="p-1.5 rounded hover:bg-[#252530] transition-colors text-[#94a3b8]" title="اختصارات لوحة المفاتيح">
            <span className="text-xs">⌨️</span>
          </button>
          <button onClick={() => setIsFullscreen(!isFullscreen)} className="p-1.5 rounded hover:bg-[#252530] transition-colors text-[#94a3b8]">
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Sidebar */}
        <div className="flex flex-col border-l border-[#2a2a3a] bg-[#111118]" style={{ width: sidebarWidth }}>
          {/* Sidebar Tabs */}
          <div className="flex border-b border-[#2a2a3a]">
            {[
              { id: 'files' as const, icon: <FolderTree className="w-4 h-4" />, label: 'الملفات' },
              { id: 'search' as const, icon: <Search className="w-4 h-4" />, label: 'بحث' },
              { id: 'map' as const, icon: <Layers className="w-4 h-4" />, label: 'خريطة' },
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActivePanel(tab.id)}
                className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 text-xs transition-colors ${
                  activePanel === tab.id ? 'text-indigo-400 border-b-2 border-indigo-400' : 'text-[#94a3b8] hover:text-white'
                }`}
              >
                {tab.icon}
                <span>{tab.label}</span>
              </button>
            ))}
          </div>

          {/* Sidebar Content */}
          <div className="flex-1 overflow-y-auto">
            {activePanel === 'files' && (
              <div className="p-2">
                {!projectIndex ? (
                  <div className="text-center py-8">
                    <FolderTree className="w-10 h-10 text-[#2a2a3a] mx-auto mb-3" />
                    <p className="text-xs text-[#94a3b8] mb-3">اختر مجلد مشروع</p>
                    <button
                      onClick={handleOpenFolder}
                      disabled={!isFSASupported}
                      className="px-4 py-2 rounded-lg bg-gradient-to-r from-indigo-500 to-cyan-500 text-white text-xs font-medium disabled:opacity-50 w-full mb-2"
                    >
                      {isFSASupported ? '📂 فتح مجلد' : '⚠️ المتصفح غير مدعوم'}
                    </button>
                    <button
                      onClick={handleStartDemo}
                      className="px-4 py-2 rounded-lg bg-[#252530] text-white text-xs font-medium hover:bg-[#2a2a3a] transition-colors w-full"
                    >
                      🎮 الوضع التجريبي
                    </button>
                    {!isFSASupported && (
                      <p className="text-[10px] text-[#94a3b8] mt-2">استخدم Chrome/Edge أو جرّب الوضع التجريبي</p>
                    )}
                  </div>
                ) : isIndexing ? (
                  <div className="text-center py-8">
                    <RefreshCw className="w-8 h-8 text-indigo-400 mx-auto mb-3 animate-spin" />
                    <p className="text-xs text-[#94a3b8]">جاري الفهرسة...</p>
                  </div>
                ) : (
                  <div>
                    <div className="flex items-center justify-between px-2 py-1.5 mb-1">
                      <span className="text-[10px] text-[#64748b]">{projectIndex.totalFiles} ملف</span>
                      <button onClick={handleOpenFolder} className="text-[10px] text-indigo-400 hover:text-indigo-300">
                        تغيير المجلد
                      </button>
                    </div>
                    {projectIndex.files.map(node => (
                      <FileTreeItem
                        key={node.path}
                        node={node}
                        depth={0}
                        selectedPath={selectedFile}
                        onSelect={handleSelectFile}
                        onToggle={toggleDir}
                        onReadFile={handleReadFile}
                      />
                    ))}
                  </div>
                )}
              </div>
            )}
            {activePanel === 'search' && (
              <SearchPanel index={projectIndex} onFileSelect={handleSelectFile} fileContents={fileContents} />
            )}
            {activePanel === 'map' && (
              <ProjectMap index={projectIndex} onFileClick={handleSelectFile} />
            )}
          </div>
        </div>

        {/* Center - Code Viewer */}
        <div className="flex-1 flex flex-col overflow-hidden">
          {selectedFile ? (
            <div className="flex-1 overflow-hidden">
              <CodeViewer content={fileContent || 'جاري التحميل...'} filename={selectedFile} />
            </div>
          ) : (
            <div className="flex-1 flex items-center justify-center">
              <div className="text-center">
                <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-indigo-500/10 to-cyan-500/10 flex items-center justify-center mx-auto mb-6">
                  <Zap className="w-10 h-10 text-indigo-400" />
                </div>
                <h2 className="text-xl font-bold mb-2">Universal Local AI Bridge</h2>
                <p className="text-sm text-[#94a3b8] mb-6 max-w-md">
                  {projectIndex 
                    ? 'اختر ملفًا من الشجرة لعرضه، أو اكتب سؤالك في لوحة المحادثة'
                    : 'افتح مجلد مشروعك للبدء'}
                </p>
                {!projectIndex && (
                  <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
                    <button
                      onClick={handleOpenFolder}
                      disabled={!isFSASupported}
                      className="px-6 py-3 rounded-xl bg-gradient-to-r from-indigo-500 to-cyan-500 text-white font-medium disabled:opacity-50"
                    >
                      <span className="flex items-center gap-2">
                        <FolderTree className="w-5 h-5" />
                        فتح مجلد المشروع
                      </span>
                    </button>
                    <button
                      onClick={handleStartDemo}
                      className="px-6 py-3 rounded-xl bg-[#111118] border border-[#2a2a3a] text-white font-medium hover:border-indigo-500/50 transition-colors"
                    >
                      <span className="flex items-center gap-2">
                        <Play className="w-5 h-5 text-indigo-400" />
                        الوضع التجريبي
                      </span>
                    </button>
                  </div>
                )}
                {!projectIndex && !isFSASupported && (
                  <p className="text-xs text-[#94a3b8] mt-4">
                    💡 متصفحك لا يدعم File System Access API. استخدم الوضع التجريبي أو افتح في Chrome/Edge.
                  </p>
                )}
                
                {/* Quick stats */}
                {projectIndex && (
                  <div className="mt-8 grid grid-cols-4 gap-4 max-w-lg mx-auto">
                    <div className="p-3 rounded-lg bg-[#111118] border border-[#2a2a3a]">
                      <p className="text-lg font-bold text-indigo-400">{projectIndex.totalFiles}</p>
                      <p className="text-[10px] text-[#94a3b8]">ملف</p>
                    </div>
                    <div className="p-3 rounded-lg bg-[#111118] border border-[#2a2a3a]">
                      <p className="text-lg font-bold text-cyan-400">{projectIndex.totalDirs}</p>
                      <p className="text-[10px] text-[#94a3b8]">مجلد</p>
                    </div>
                    <div className="p-3 rounded-lg bg-[#111118] border border-[#2a2a3a]">
                      <p className="text-lg font-bold text-green-400">{formatFileSize(projectIndex.totalSize)}</p>
                      <p className="text-[10px] text-[#94a3b8]">الحجم</p>
                    </div>
                    <div className="p-3 rounded-lg bg-[#111118] border border-[#2a2a3a]">
                      <p className="text-lg font-bold text-purple-400">{Object.keys(projectIndex.extensions).length}</p>
                      <p className="text-[10px] text-[#94a3b8]">نوع ملف</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Right Panel */}
        <div className="flex flex-col border-r border-[#2a2a3a] bg-[#111118]" style={{ width: rightPanelWidth }}>
          {/* Right Panel Tabs */}
          <div className="flex border-b border-[#2a2a3a] overflow-x-auto">
            {[
              { id: 'chat' as const, icon: <Brain className="w-4 h-4" />, label: 'AI' },
              { id: 'bridge' as const, icon: <Zap className="w-4 h-4" />, label: 'Bridge' },
              { id: 'agent' as const, icon: <Cpu className="w-4 h-4" />, label: 'Agent' },
              { id: 'contextBuilder' as const, icon: <Layers className="w-4 h-4" />, label: 'السياق' },
              { id: 'memory' as const, icon: <Brain className="w-4 h-4" />, label: 'الذاكرة' },
              { id: 'permissions' as const, icon: <Shield className="w-4 h-4" />, label: 'الصلاحيات' },
              { id: 'tasks' as const, icon: <Clock className="w-4 h-4" />, label: 'المهام' },
              { id: 'compare' as const, icon: <Globe className="w-4 h-4" />, label: 'مقارنة' },
              { id: 'git' as const, icon: <GitBranch className="w-4 h-4" />, label: 'Git' },
              { id: 'terminal' as const, icon: <Terminal className="w-4 h-4" />, label: 'Terminal' },
              { id: 'settings' as const, icon: <SettingsIcon className="w-4 h-4" />, label: 'إعدادات' },
              { id: 'log' as const, icon: <Clock className="w-4 h-4" />, label: 'السجل' },
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActivePanel(tab.id)}
                className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 text-xs transition-colors ${
                  activePanel === tab.id ? 'text-indigo-400 border-b-2 border-indigo-400' : 'text-[#94a3b8] hover:text-white'
                }`}
              >
                {tab.icon}
                <span>{tab.label}</span>
              </button>
            ))}
          </div>

          {/* Right Panel Content */}
          <div className="flex-1 overflow-hidden">
            {activePanel === 'chat' && (
              <ChatPanel onExtractContext={handleExtractContext} isLoading={isContextLoading} onAiResponse={setAiResponse} />
            )}
            {activePanel === 'context' && (
              <ContextPanel context={context} onCopyContext={handleCopyContext} onExportContext={handleExportContext} isCopied={isCopied} />
            )}
            {activePanel === 'compare' && (
              <AIComparison context={context} fileContents={fileContents} query={lastQuery} />
            )}
            {activePanel === 'log' && (
              <OperationLog logs={operationLog} onClear={() => setOperationLog([])} />
            )}
            {activePanel === 'bridge' && (
              <AIBridgePanel
                context={context}
                fileContents={fileContents}
                query={lastQuery}
                projectName={projectIndex?.rootName || 'No Project'}
                projectStructure={projectIndex ? projectIndex.files.map(f => f.name).join('\n') : ''}
                permissionMode={permissionMode}
              />
            )}
            {activePanel === 'agent' && (
              <AgentModePanel
                aiResponse={aiResponse}
                fileContents={fileContents}
                onExecuteCommand={async (cmd, params) => {
                  addLog('Agent Execute', `${cmd} ${JSON.stringify(params)}`);
                  return { success: true };
                }}
                onApplyModification={async (path, content) => {
                  addLog('Agent Modify', path);
                  return true;
                }}
              />
            )}
            {activePanel === 'contextBuilder' && (
              <ContextBuilder
                projectIndex={projectIndex}
                selectedFiles={selectedContextFiles}
                pinnedFiles={pinnedContextFiles}
                excludedPaths={excludedContextPaths}
                onToggleFile={(path) => {
                  setSelectedContextFiles(prev =>
                    prev.includes(path) ? prev.filter(p => p !== path) : [...prev, path]
                  );
                }}
                onTogglePin={(path) => {
                  setPinnedContextFiles(prev =>
                    prev.includes(path) ? prev.filter(p => p !== path) : [...prev, path]
                  );
                }}
                onToggleExclude={(path) => {
                  setExcludedContextPaths(prev =>
                    prev.includes(path) ? prev.filter(p => p !== path) : [...prev, path]
                  );
                }}
              />
            )}
            {activePanel === 'memory' && currentProjectMemory && (
              <LocalMemoryPanel
                projectMemory={currentProjectMemory}
                onUpdateMemory={handleUpdateMemory}
              />
            )}
            {activePanel === 'permissions' && (
              <PermissionCenter
                config={permissionConfig}
                onUpdate={setPermissionConfig}
              />
            )}
            {activePanel === 'tasks' && (
              <TaskHistory
                tasks={tasks}
                onClear={() => setTasks([])}
                onExport={() => {
                  const data = JSON.stringify(tasks, null, 2);
                  const blob = new Blob([data], { type: 'application/json' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = `ulab-tasks-${Date.now()}.json`;
                  a.click();
                  URL.revokeObjectURL(url);
                  addLog('تصدير المهام', `${tasks.length} مهمة`);
                }}
              />
            )}
            {activePanel === 'git' && (
              <GitPanel gitInfo={projectIndex?.rootName === 'demo-project' ? DEMO_GIT_INFO : null} />
            )}
            {activePanel === 'terminal' && (
              <TerminalPanel permissionMode={permissionMode} />
            )}
            {activePanel === 'settings' && (
              <SettingsPanel settings={settings} onSettingsChange={setSettings} />
            )}
          </div>
        </div>
      </div>

      {/* Approval Modal */}
      {pendingApproval && (
        <ApprovalModal
          action={pendingApproval}
          onApprove={(once) => {
            addLog('موافقة', `${pendingApproval.type} - ${pendingApproval.resource}`);
            notifications.success('تمت الموافقة', `${pendingApproval.description}`);
            setPendingApproval(null);
          }}
          onDeny={() => {
            addLog('رفض', `${pendingApproval.type} - ${pendingApproval.resource}`);
            notifications.warning('تم الرفض', `${pendingApproval.description}`);
            setPendingApproval(null);
          }}
        />
      )}

      {/* Welcome Modal */}
      <WelcomeModal
        isOpen={showWelcome}
        onClose={() => setShowWelcome(false)}
        onOpenFolder={handleOpenFolder}
        onStartDemo={handleStartDemo}
      />

      {/* Notification System */}
      <NotificationSystem
        notifications={notifications.notifications}
        onRemove={notifications.removeNotification}
      />

      {/* Keyboard Shortcuts Modal */}
      <KeyboardShortcutsModal
        isOpen={showShortcuts}
        onClose={() => setShowShortcuts(false)}
      />

      {/* Status Bar */}
      <footer className="h-7 border-t border-[#2a2a3a] flex items-center px-4 gap-4 text-[10px] text-[#64748b] flex-shrink-0 bg-[#111118]">
        <span className="flex items-center gap-1">
          <div className={`w-1.5 h-1.5 rounded-full ${
            agentConnection.status === 'connected' ? 'bg-green-400' :
            agentConnection.status === 'connecting' ? 'bg-yellow-400 animate-pulse' :
            'bg-red-400'
          }`}></div>
          {agentConnection.status === 'connected' ? 'Agent Connected' :
           agentConnection.status === 'connecting' ? 'Connecting...' :
           'Disconnected'}
        </span>
        <span className="flex items-center gap-1">
          <Shield className="w-3 h-3 text-green-400" />
          Security: Active
        </span>
        {selectedFile && (
          <span className="flex items-center gap-1">
            <File className="w-3 h-3" />
            {selectedFile}
          </span>
        )}
        <span className="mr-auto flex items-center gap-1">
          <Shield className="w-3 h-3" />
          {permissionMode === 'readonly' ? 'وضع القراءة' : permissionMode === 'assisted' ? 'بمساعدة' : 'وكيل'}
        </span>
        <span>ULP v0.1</span>
        <span className="hidden sm:flex items-center gap-2 text-[#4a5568]">
          <span className="px-1 rounded bg-[#252530] text-[9px]">Ctrl+O</span> فتح
          <span className="px-1 rounded bg-[#252530] text-[9px]">Ctrl+F</span> بحث
          <span className="px-1 rounded bg-[#252530] text-[9px]">Ctrl+1-3</span> تبديل
        </span>
        <span className="flex items-center gap-1">
          <Lock className="w-3 h-3 text-green-400" />
          محلي
        </span>
      </footer>

      {/* Permission Modal */}
      <PermissionModal
        isOpen={showPermissions}
        onClose={() => setShowPermissions(false)}
        mode={permissionMode}
        onModeChange={(m) => { setPermissionMode(m); addLog('تغيير الصلاحية', m); }}
      />
    </div>
  );
}
