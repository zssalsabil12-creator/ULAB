// Local Agent Connection Layer
// This is the abstraction for communicating with the local agent
// In Phase 1 (Web Dashboard): Uses File System Access API directly
// In Phase 2 (Extension): Will use Chrome Native Messaging

export type ConnectionStatus = 'disconnected' | 'connecting' | 'connected' | 'error';

export interface AgentConnection {
  status: ConnectionStatus;
  version?: string;
  platform?: string;
  capabilities: AgentCapabilities;
}

export interface AgentCapabilities {
  fileSystem: boolean;
  git: boolean;
  terminal: boolean;
  browser: boolean;
  notifications: boolean;
}

export interface AgentMessage {
  id: string;
  type: 'request' | 'response' | 'event';
  action: string;
  params?: Record<string, any>;
  result?: any;
  error?: string;
  timestamp: number;
}

// ============ CONNECTION MANAGER ============

class LocalAgentManager {
  private status: ConnectionStatus = 'disconnected';
  private capabilities: AgentCapabilities = {
    fileSystem: false,
    git: false,
    terminal: false,
    browser: false,
    notifications: false,
  };
  private listeners: Set<(status: ConnectionStatus) => void> = new Set();

  constructor() {
    this.detectCapabilities();
  }

  private detectCapabilities() {
    // Phase 1: Detect browser capabilities
    if ('showDirectoryPicker' in window) {
      this.capabilities.fileSystem = true;
    }

    // In Phase 1, we use browser APIs directly
    // In Phase 2, the local agent will provide these
    this.capabilities.git = false; // Requires local agent
    this.capabilities.terminal = false; // Requires local agent
    this.capabilities.browser = false; // Requires extension
    this.capabilities.notifications = 'Notification' in window;

    // Auto-connect if file system is available
    if (this.capabilities.fileSystem) {
      this.status = 'connected';
    }
  }

  getStatus(): ConnectionStatus {
    return this.status;
  }

  getCapabilities(): AgentCapabilities {
    return { ...this.capabilities };
  }

  getConnection(): AgentConnection {
    return {
      status: this.status,
      version: '0.3.0-web',
      platform: this.getPlatform(),
      capabilities: this.getCapabilities(),
    };
  }

  private getPlatform(): string {
    const ua = navigator.userAgent;
    if (ua.includes('Windows')) return 'Windows (Browser)';
    if (ua.includes('Mac')) return 'macOS (Browser)';
    if (ua.includes('Linux')) return 'Linux (Browser)';
    return 'Unknown (Browser)';
  }

  onStatusChange(listener: (status: ConnectionStatus) => void) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notifyListeners() {
    this.listeners.forEach(listener => listener(this.status));
  }

  // Phase 1: Direct browser operations
  async selectDirectory(): Promise<FileSystemDirectoryHandle | null> {
    try {
      const handle = await (window as any).showDirectoryPicker({
        mode: 'readwrite',
      });
      return handle;
    } catch (e) {
      console.error('Directory selection failed:', e);
      return null;
    }
  }

  // Phase 2: Will communicate with local agent via Native Messaging
  async sendMessage(message: AgentMessage): Promise<AgentMessage> {
    // Phase 1: Handle directly in browser
    return this.handleLocally(message);
  }

  private async handleLocally(message: AgentMessage): Promise<AgentMessage> {
    // In Phase 1, we handle file operations directly via File System Access API
    // In Phase 2, this will be sent to the local agent

    switch (message.action) {
      case 'ping':
        return {
          ...message,
          type: 'response',
          result: { status: 'ok', timestamp: Date.now() },
          timestamp: Date.now(),
        };

      case 'getCapabilities':
        return {
          ...message,
          type: 'response',
          result: this.getCapabilities(),
          timestamp: Date.now(),
        };

      default:
        return {
          ...message,
          type: 'response',
          error: `Action not supported in browser mode: ${message.action}`,
          timestamp: Date.now(),
        };
    }
  }
}

// Singleton instance
export const localAgent = new LocalAgentManager();

// ============ NATIVE MESSAGING INTERFACE (Phase 2) ============

/*
 * Phase 2: Chrome Extension Native Messaging
 * 
 * The extension will communicate with the local agent using
 * Chrome's native messaging API:
 * 
 * ```typescript
 * // In extension background script
 * const port = chrome.runtime.connectNative('com.ulab.agent');
 * 
 * port.onMessage.addListener((message) => {
 *   // Handle response from local agent
 * });
 * 
 * port.postMessage({
 *   action: 'files.read',
 *   params: { path: '/path/to/file' }
 * });
 * ```
 * 
 * The local agent (Node.js) will:
 * 1. Register as a native messaging host
 * 2. Listen for messages on stdin
 * 3. Process requests using Node.js APIs
 * 4. Send responses on stdout
 * 
 * This provides:
 * - Full file system access
 * - Git operations
 * - Terminal execution
 * - Process management
 * - No browser limitations
 */

export interface NativeMessageHost {
  name: string;
  description: string;
  path: string;
  type: 'stdio';
  allowed_origins: string[];
}

// This will be the manifest for the native messaging host
export const NATIVE_HOST_MANIFEST: NativeMessageHost = {
  name: 'com.ulab.agent',
  description: 'ULAB Local Agent',
  path: '/path/to/ulab-agent', // Will be set during installation
  type: 'stdio',
  allowed_origins: [
    'chrome-extension://EXTENSION_ID/',
  ],
};

// ============ PHASE 2 AGENT PROTOCOL ============

/*
 * Phase 2: Local Agent Protocol
 * 
 * Request format:
 * ```json
 * {
 *   "id": "msg-123",
 *   "type": "request",
 *   "action": "files.read",
 *   "params": {
 *     "path": "/path/to/file.ts"
 *   },
 *   "timestamp": 1234567890
 * }
 * ```
 * 
 * Response format:
 * ```json
 * {
 *   "id": "msg-123",
 *   "type": "response",
 *   "action": "files.read",
 *   "result": {
 *     "content": "file contents..."
 *   },
 *   "timestamp": 1234567891
 * }
 * ```
 * 
 * Error response:
 * ```json
 * {
 *   "id": "msg-123",
 *   "type": "response",
 *   "action": "files.read",
 *   "error": "Permission denied",
 *   "timestamp": 1234567891
 * }
 * ```
 */

// ============ CONNECTION STATUS HOOK ============

import { useState, useEffect } from 'react';

export function useAgentConnection() {
  const [connection, setConnection] = useState<AgentConnection>(
    localAgent.getConnection()
  );

  useEffect(() => {
    const unsubscribe = localAgent.onStatusChange(() => {
      setConnection(localAgent.getConnection());
    });
    return () => { unsubscribe(); };
  }, []);

  return connection;
}
